# 本地开发配置

把 `YOUR_WECHAT_APPID` 替换为你获授权的小程序开发 AppID，把 `YOUR_CLOUDBASE_ENV_ID` 替换为独立开发云环境 ID。以下文件包含占位符，需统一配置：

- `app.js`
- `cloudbaserc.json`
- `cloudfunctions/rhythm-api/dispatch.js`
- `cloudfunctions/rhythm-api/index.js`
- `cloudfunctions/rhythm-api/wallpaper.js`
- `cloudfunctions/rhythm-forecast/dispatch.js`
- `cloudfunctions/rhythm-forecast/index.js`
- `cloudfunctions/rhythm-wallpaper-preview/index.js`
- `cloudfunctions/rhythm-wallpaper/index.js`
- `project.config.json`

`cloudbaserc.json` 只覆盖部分函数，不代表完整部署声明。云函数依赖各自安装；服务端凭据仅在受控环境变量中配置，ENVIRONMENT.md 只列名称。未完成环境配置前，云同步与生成能力不可用。不要把生产身份或密钥填进公开提交。
