'use strict';
const crypto=require('crypto');
const cloud=require('wx-server-sdk');
const cloudbase=require('@cloudbase/node-sdk');
const {buildPrompt,VERSION}=require('./prompt');
const {downloadImage}=require('./download');
cloud.init({env:cloud.DYNAMIC_CURRENT_ENV});
const env=process.env.ENV_ID||'YOUR_CLOUDBASE_ENV_ID';
const app=cloudbase.init({env}),db=cloud.database();
const MODEL='HY-Image-3.0-Plus-4090-Tob-v1.0';
const TRIGGER='wallpaper-next-day-20h';
const tomorrow=()=>new Date(Date.now()+28800000+86400000).toISOString().slice(0,10);
const safeError=e=>/^(IMAGE_[A-Z_]+|WALLPAPER_[A-Z_]+)$/.test(e&&e.message||'')?e.message:'WALLPAPER_GENERATION_FAILED';
async function get(ref){try{return (await ref.get()).data;}catch(e){if(e.errCode===-502001||/not exist|not found|不存在/i.test(e.errMsg||e.message||''))return null;throw e;}}
function authorize(event){
 const context=cloud.getWXContext();if(context.OPENID||context.APPID)throw new Error('UNAUTHORIZED');
 if(event.Type==='Timer'&&event.TriggerName===TRIGGER)return;
 const expected=process.env.WALLPAPER_INTERNAL_TOKEN,supplied=event.token;
 if(event.internal===true&&expected&&typeof supplied==='string'&&Buffer.byteLength(supplied)===Buffer.byteLength(expected)&&crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(expected)))return;
 throw new Error('UNAUTHORIZED');
}
async function claim(date,design){return db.runTransaction(async tx=>{
 const manifest=await get(tx.collection('wallpapers').doc(date));if(manifest)return {skip:'manifest_exists'};
 const ref=tx.collection('wallpaper_jobs').doc(date),old=await get(ref),now=Date.now();
 if(old&&old.leaseUntil>now)return {skip:'busy'};
 if(old&&old.generationRequested&&!old.imageUrl)return {skip:'uncertain_previous_request'};
 const leaseToken=crypto.randomUUID(),next=Object.assign({},old||{date,generationId:crypto.randomUUID(),provider:'tencent-cloudbase-hunyuan',model:MODEL,ganzhi:design.ganzhi,element:design.element,promptVersion:VERSION,wallpaperKind:design.variation.kind,generationRequested:false},{status:'running',leaseToken,leaseUntil:now+960000,updatedAt:now});
 if(!next.generationRequested&&!next.imageUrl){next.promptVersion=VERSION;next.wallpaperKind=design.variation.kind;}
 // Database document identities are returned by get(), but cannot be set as data.
 delete next._id;delete next._openid;
 await ref.set({data:next});return next;
});}
async function patch(date,job,data){return db.runTransaction(async tx=>{const ref=tx.collection('wallpaper_jobs').doc(date),current=await get(ref);if(!current||current.generationId!==job.generationId||current.leaseToken!==job.leaseToken)return false;await ref.update({data:{...data,updatedAt:Date.now()}});return true;});}
function jpeg(buffer){
 if(buffer[0]===0xff&&buffer[1]===0xd8&&buffer[2]===0xff)return buffer;
 if(buffer.length<24||buffer.toString('hex',0,8)!=='89504e470d0a1a0a')throw new Error('IMAGE_FORMAT_INVALID');
 const width=buffer.readUInt32BE(16),height=buffer.readUInt32BE(20);if(!width||!height||width*height>16777216)throw new Error('IMAGE_DIMENSIONS_INVALID');
 const png=require('pngjs').PNG.sync.read(buffer,{checkCRC:true});
 // The wallpaper storage path is .jpg; flatten transparent PNG onto the paper tone.
 for(let i=0;i<png.data.length;i+=4){const a=png.data[i+3]/255;png.data[i]=Math.round(png.data[i]*a+247*(1-a));png.data[i+1]=Math.round(png.data[i+1]*a+246*(1-a));png.data[i+2]=Math.round(png.data[i+2]*a+242*(1-a));png.data[i+3]=255;}
 return require('jpeg-js').encode({data:png.data,width:png.width,height:png.height},82).data;
}
exports.main=async(event={})=>{
 authorize(event);const date=tomorrow();
 if(await get(db.collection('wallpapers').doc(date)))return {status:'skipped',reason:'manifest_exists',date};
 // Keep disabled until the free Growth Plan image resource has actually arrived.
 // There is no alternate provider or paid fallback in this function.
 if(process.env.WALLPAPER_RESOURCE_READY!=='true')return {status:'awaiting_resource',date};
 const design=buildPrompt(date);let job;
 try{
  try{job=await claim(date,design);}catch(error){throw new Error('WALLPAPER_CLAIM_FAILED');}
  if(job.skip)return {status:'skipped',reason:job.skip,date};
  let imageUrl=job.imageUrl;
  if(!imageUrl){
   if(!await patch(date,job,{generationRequested:true,status:'generating'}))return {status:'superseded',date};
   const model=app.ai().createImageModel('hunyuan-image');
   const response=await model.generateImage({model:MODEL,prompt:design.prompt,size:'720x1280',revise:{value:true}});
   imageUrl=response&&response.data&&response.data[0]&&response.data[0].url;
   if(typeof imageUrl!=='string')throw new Error('IMAGE_RESPONSE_INVALID');
   let host;try{host=new URL(imageUrl).hostname;}catch(e){throw new Error('IMAGE_URL_INVALID');}
   if(!await patch(date,job,{imageUrl,imageHost:host,imageReceivedAt:Date.now(),status:'generated'}))return {status:'superseded',date};
  }
  const downloaded=await downloadImage(imageUrl),image=jpeg(downloaded.buffer||downloaded);
  if(await get(db.collection('wallpapers').doc(date))){await patch(date,job,{status:'skipped',leaseUntil:0,leaseToken:''});return {status:'skipped',reason:'manifest_exists',date};}
  const upload=await app.uploadFile({cloudPath:'wallpapers/'+date+'.jpg',fileContent:image});if(!upload.fileID)throw new Error('IMAGE_UPLOAD_FAILED');
  const manifest={date,fileId:upload.fileID,kind:'ai_generated',provider:'tencent-cloudbase-hunyuan',model:MODEL,ganzhi:design.ganzhi,element:design.element,generationId:job.generationId,generatedAt:new Date().toISOString(),promptVersion:job.promptVersion||'v1',...(job.wallpaperKind?{wallpaperKind:job.wallpaperKind}:{})};
  const saved=await db.runTransaction(async tx=>{const ref=tx.collection('wallpapers').doc(date),existing=await get(ref),jobRef=tx.collection('wallpaper_jobs').doc(date),current=await get(jobRef);if(existing||!current||current.generationId!==job.generationId||current.leaseToken!==job.leaseToken)return false;await ref.set({data:manifest});await jobRef.update({data:{status:'complete',fileId:upload.fileID,imageUrl:db.command.remove(),leaseUntil:0,leaseToken:'',updatedAt:Date.now()}});return true;});
  return {status:saved?'complete':'skipped',date};
 }catch(error){const code=safeError(error),diagnostic=error&&error.imageDiagnostic;const extra=diagnostic?{imageDiagnostic:diagnostic}:{};if(job&&!job.skip)await patch(date,job,{status:'failed',error:code,leaseUntil:0,leaseToken:'',...extra}).catch(()=>{});return {status:'failed',error:code,date,...extra};}
};
