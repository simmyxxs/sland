'use strict';
const fs=require('fs');
const VERSION='rhythm-copy-v2-four-by-four';
const BATCH_SUFFIX='\n本次一次生成未来一个月的一批逐日预测。请逐日综合，不把未来体感写成已经发生，不补造事件；历法和身体预测与象征解释需区分。用户反馈只作为已知参考。返回JSON对象 {"days":[{"date":"YYYY-MM-DD","result":上述规定的完整JSON对象}]}，日期必须与本批输入一一对应。每一天都要有完整headline、suggestion、explanation、caveat、fact_vs_interpretation，evidence_ids仅引用该日facts键。不需要重复说明模型工作方式。';
function buildSystemPrompt(){return fs.readFileSync(__dirname+'/system-prompt.txt','utf8')+'\n以下仅是用户已授权公用的语言风格例句，每组只有标题和方向句。只学习抽象、凝练、自然隐喻的表达方式，不得把示例当作当前用户事实、不得套用其身体阶段、五行或日期，也不得照抄为本批答案。当前事实只来自各自 days[].facts。\n'+JSON.stringify(require('./style-examples.json'))+BATCH_SUFFIX;}
module.exports={VERSION,buildSystemPrompt};
