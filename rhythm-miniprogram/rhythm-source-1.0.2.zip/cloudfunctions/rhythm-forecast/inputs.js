'use strict';
const {Solar}=require('./vendor/lunar');
const {canonicalSource}=require('./source');
const iso=d=>d.toISOString().slice(0,10);
const today=()=>iso(new Date(Date.now()+8*3600000));
const stamp=s=>Date.parse(s+'T12:00:00+08:00');
const add=(s,n)=>iso(new Date(stamp(s)+n*86400000));
function moon(date){
 const days=stamp(date)/86400000+2440587.5-2451545,rad=Math.PI/180,e=rad*23.4397;
 const coords=(l,b)=>[Math.atan2(Math.sin(l)*Math.cos(e)-Math.tan(b)*Math.sin(e),Math.cos(l)),Math.asin(Math.sin(b)*Math.cos(e)+Math.cos(b)*Math.sin(e)*Math.sin(l))];
 const M=rad*(357.5291+.98560028*days),L=M+rad*(1.9148*Math.sin(M)+.02*Math.sin(2*M)+.0003*Math.sin(3*M))+rad*102.9372+Math.PI;
 const [sra,sdec]=coords(L,0),lm=rad*(218.316+13.176396*days),mm=rad*(134.963+13.064993*days),f=rad*(93.272+13.229350*days);
 const [mra,mdec]=coords(lm+rad*6.289*Math.sin(mm),rad*5.128*Math.sin(f)),dist=385001-20905*Math.cos(mm);
 const phi=Math.acos(Math.max(-1,Math.min(1,Math.sin(sdec)*Math.sin(mdec)+Math.cos(sdec)*Math.cos(mdec)*Math.cos(sra-mra))));
 const inc=Math.atan2(149598000*Math.sin(phi),dist-149598000*Math.cos(phi)),angle=Math.atan2(Math.cos(sdec)*Math.sin(sra-mra),Math.sin(sdec)*Math.cos(mdec)-Math.cos(sdec)*Math.sin(mdec)*Math.cos(sra-mra));
 const phase=(.5+.5*inc*(angle<0?-1:1)/Math.PI+1)%1;
 return {phase_fraction:phase,phase_name:['新月','蛾眉月','上弦月','盈凸月','满月','亏凸月','下弦月','残月'][Math.floor(phase*8+.5)%8],illumination:Math.round((1+Math.cos(inc))*50)};
}
function body(date,state,asOf=today()){
 const rows=state.periods.filter(r=>r.start_date<=date).sort((a,b)=>b.start_date.localeCompare(a.start_date));
 const base={phase:'unknown',label:'阶段待确认',quality:'unknown',explanation:'记录月经日期，观察身体节律。'};
 if(!rows.length)return base;
 const latest=rows[0],active=(!latest.end_date?date<=asOf:date<=latest.end_date);
 const durations=rows.filter(r=>r.end_date&&r.end_date<=date).map(r=>Math.round((stamp(r.end_date)-stamp(r.start_date))/86400000)+1);
 const gaps=rows.slice(1).map((r,i)=>Math.round((stamp(rows[i].start_date)-stamp(r.start_date))/86400000));
 const avg=gaps.length?Math.round(gaps.reduce((a,b)=>a+b,0)/gaps.length):Number(state.cycleLength)||0;
 if(active)return Object.assign(base,{phase:'menstrual',label:'月经期',quality:'recorded',explanation:`实际记录：${latest.start_date} — ${latest.end_date||'进行中'}。`});
 if(!avg)return Object.assign(base,{explanation:'记录下一次月经，逐步看见周期。'});
 let expected=add(latest.start_date,avg),n=Math.round((stamp(date)-stamp(latest.start_date))/86400000)+1;
 if(date>=expected&&date<=asOf)return Object.assign(base,{label:'阶段待更新',explanation:'经期已到，记录这次月经可更新身体阶段。'});
 let phase;
 if(date>=expected){let projected=expected;while(add(projected,avg)<=date)projected=add(projected,avg);n=Math.round((stamp(date)-stamp(projected))/86400000)+1;expected=add(projected,avg);const bleeding=durations.length?Math.round(durations.reduce((a,b)=>a+b,0)/durations.length):3;phase=n<=bleeding?'menstrual':date<add(expected,-16)?'follicular':date<=add(expected,-12)?'ovulatory':'luteal';}
 else phase=date<add(expected,-16)?'follicular':date<=add(expected,-12)?'ovulatory':'luteal';
 return {phase,label:{menstrual:'月经期',follicular:'卵泡期',ovulatory:'排卵期',luteal:'黄体期'}[phase],quality:'estimated',explanation:`${gaps.length?'记录的平均':'参考'}周期 ${avg} 天，下次月经 ${expected}。`};
}
const fact=(value,quality,source)=>({value,quality,source});
function chart(state){
 const c=state.manualChart||{},b=state.birth||{};
 if(state.chartSource==='manual'&&c.year&&c.month&&c.day)return {year:c.year,month:c.month,day:c.day,time:c.unknown?null:c.time||null,source:'用户主动填写的出生干支；未另行验证出生历法'};
 if(!b.date)return null;
 const [y,m,d]=b.date.split('-').map(Number),[h,min]=(b.unknown?'12:00':b.time||'12:00').split(':').map(Number);
 const ec=Solar.fromYmdHms(y,m,d,h,min,0).getLunar().getEightChar();
 // 未知时间用正午仅计算日期对应三柱，绝不输出推定时柱。
 return {year:ec.getYear(),month:ec.getMonth(),day:ec.getDay(),time:b.unknown||!b.time?null:ec.getTime(),source:'用户出生公历资料，按北京时间由 lunar-javascript 计算；出生地仅记录，未校正真太阳时'};
}
// Only explicit owner-owned facts can supplement missing inputs. Calendar/body facts cannot be overridden.
function storedFact(personal,key,date,asOf){
 const raw=personal&&personal[key];if(raw==null)return null;
 let entry=raw;
 if(Array.isArray(raw)){entry=raw.find(v=>applicable(v,key,date,asOf));if(!entry)return null;}
 else if(raw&&typeof raw==='object'&&!Object.prototype.hasOwnProperty.call(raw,'value')&&Object.prototype.hasOwnProperty.call(raw,date))entry={...raw[date],date};
 if(!entry||typeof entry!=='object'||Array.isArray(entry)||!Object.prototype.hasOwnProperty.call(entry,'value')||!applicable(entry,key,date,asOf))return null;
 const quality=typeof entry.quality==='string'?entry.quality:typeof entry.status==='string'?entry.status:'provided';
 if(entry.value==null||quality==='unknown')return null;
 return fact(entry.value,quality,typeof entry.source==='string'&&entry.source.trim()?entry.source:'当前用户已保存的个人资料；未另行推算');
}
function applicable(entry,key,date,asOf){
 if(!entry||typeof entry!=='object')return false;
 const target=entry.date||entry.reference_date,from=entry.valid_from||entry.effective_from||entry.start_date,to=entry.valid_to||entry.effective_to||entry.end_date;
 if([target,from,to,entry.as_of,entry.recorded_date].some(v=>v&&!(typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v)))return false;
 if(target&&target!==date||from&&date<from||to&&date>to)return false;
 if(entry.as_of&&entry.as_of>asOf||entry.recorded_date&&entry.recorded_date>asOf)return false;
 if(['context','sleep','felt_energy'].includes(key)){
  if(date>asOf)return false;
  // Daily observations cannot silently become permanent facts.
  if(!target&&!(from&&to))return false;
 }
 return true;
}
function buildInput(date,state,asOf=today()){
 state=canonicalSource(state);
 const [y,m,d]=date.split('-').map(Number),l=Solar.fromYmdHms(y,m,d,12,0,0).getLunar();
 const records=(state.periods||[]).filter(p=>p.start_date<=asOf&&p.start_date<=date).sort((a,b)=>b.start_date.localeCompare(a.start_date));
 const bodyState=body(date,{...state,periods:records},asOf),birthChart=chart(state),mo=moon(date);
 const feedbacks=state.feedbacks||{},current= date<=asOf?feedbacks[date]||null:null;
 const season={menstrual:'inner_winter',follicular:'inner_spring',ovulatory:'inner_summer',luteal:'inner_autumn'}[bodyState.phase]||null;
 const gaps=records.slice(1).map((p,i)=>Math.round((stamp(records[i].start_date)-stamp(p.start_date))/86400000));
 const average=gaps.length?Math.round(gaps.reduce((a,b)=>a+b,0)/gaps.length):state.cycleLength||null;
 const facts={
  local_date:fact(date,'calendar','目标民用日期，Asia/Shanghai，00:00换日，解读整天'),
  timezone:fact('Asia/Shanghai','configured','应用采用北京时间'),
  actual_menstrual_records:fact(records.map(p=>({start_date:p.start_date,end_date:p.end_date||null})),'recorded','用户实际填写的经期记录；截至 forecast_as_of，非自动同步'),
  body_season:fact(season,season?(date>asOf?'estimated':bodyState.quality):'unknown',bodyState.explanation+' 内在四季属于象征解释；经期外阶段和未来阶段按参考周期估计，未确认排卵。'),
  body_phase:fact(bodyState.phase,bodyState.phase==='unknown'?'unknown':date>asOf?'estimated':bodyState.quality,bodyState.explanation),
  cycle_length_days:fact(average,average?(gaps.length?'historical_average':'user_reference'):'unknown',gaps.length?'实际相邻经期开始日差的平均值，仅作预测参考':'用户可选填写的参考周期；未填写不补造'),
  observed_cycle_lengths:fact(gaps,'calculated_from_records','相邻实际经期开始日差'),
  moon_phase:fact(mo,'calculated_approximate','复用小程序近似月相算法，SunCalc 公式；非精密星历'),
  day_pillar:fact(l.getDayInGanZhi(),'calendar','lunar-javascript，目标日期北京时间正午'),
  year_pillar:fact(l.getYearInGanZhiByLiChun(),'calendar','lunar-javascript，以立春换年'),
  month_pillar:fact(l.getMonthInGanZhi(),'calendar','lunar-javascript，节令月干支'),
  solar_term:fact(l.getPrevJieQi().getName(),'calendar','lunar-javascript，目标日正午之前最近节气；背景信息'),
  birth_pillars:fact(birthChart?{year:birthChart.year,month:birthChart.month,day:birthChart.day,time:birthChart.time}:null,birthChart?'provided_or_calculated':'unknown',birthChart?birthChart.source:'未填写出生资料或手动干支'),
  day_master:fact(birthChart?birthChart.day[0]:null,birthChart?'provided_or_calculated':'unknown',birthChart?birthChart.source+'；日主取日柱天干，其关系属于传统象征解释':'出生资料未知，不补造个人日主'),
  luck_pillar:fact(null,'unknown','尚未收集并实现推大运必要资料与算法；不得补造大运'),
  context:fact(null,'unknown','未主动填写当天情境'),
  sleep:fact(null,'unknown','未连接睡眠数据'),
  felt_energy:fact(current?{note:current.note||'',prediction_accuracy:current.prediction_accuracy==null?null:current.prediction_accuracy}:null,current?'recorded':'unknown',current?'用户实际保存的当天感受及预测准确度评分；评分不等同于精力水平':'没有目标日期实际反馈，不补造体感')
 };
 for(const key of ['luck_pillar','context','sleep','felt_energy','birth_pillars','day_master']){
  if(facts[key].quality!=='unknown')continue;
  const stored=storedFact(state.personalFacts,key,date,asOf);if(stored)facts[key]=stored;
 }
 const user_feedback=Object.keys(feedbacks).filter(k=>k<=asOf&&k>=add(asOf,-6)).sort().map(k=>({date:k,note:feedbacks[k].note||'',prediction_accuracy:feedbacks[k].prediction_accuracy==null?null:feedbacks[k].prediction_accuracy}));
 return {schema_version:'1.0.0',reference_date:date,forecast_as_of:asOf,facts,user_feedback};
}
module.exports={buildInput,moon,body,today,add};
