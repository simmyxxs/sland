'use strict';
const cloud=require('wx-server-sdk'),crypto=require('crypto');
const {buildInput,today}=require('./inputs');
const {validateInput,validateResult}=require('./validate');
const {VERSION,buildSystemPrompt}=require('./contract');
cloud.init({env:cloud.DYNAMIC_CURRENT_ENV});const db=cloud.database();
const digest=x=>crypto.createHash('sha256').update(x).digest('hex');
const token=()=>crypto.randomBytes(20).toString('hex');
const {ownerSource,sourceHash}=require('./source');
const planner=require('./forecast');
async function get(ref){try{return (await ref.get()).data;}catch(e){if(e.errCode===-502001||/not exist|not found|不存在/i.test(e.errMsg||e.message||''))return null;throw e;}}
const jobRef=id=>db.collection('forecast_jobs').doc(id);
async function pick(event,openid){
 if(openid){const own=digest(openid);if(event.userId&&event.userId!==own)throw new Error('UNAUTHORIZED');return own;}
 if(event.Type!=='Timer'&&event.internal!==true)throw new Error('UNAUTHORIZED');
 if(event.userId){if(!/^[a-f0-9]{64}$/.test(event.userId))throw new Error('INVALID_USER');return event.userId;}
 const now=Date.now();
 for(const status of ['queued','running','failed','awaiting_config']){
  let criteria={status};if(status==='running')criteria.leaseUntil=db.command.lt(now);if(status==='failed'){criteria.nextRetryAt=db.command.lte(now);criteria.attempts=db.command.lt(3);}
  const found=await db.collection('forecast_jobs').where(criteria).limit(1).get();
  if(found.data.length){const j=found.data[0];if(status==='failed'&&j.attempts>=3)continue;return j._id;}
 }
 return null;
}
async function claim(id){return db.runTransaction(async tx=>{
 const ref=tx.collection('forecast_jobs').doc(id),j=await get(ref),now=Date.now();
 if(!j||j.contractVersion!==2||j.promptVersion!==VERSION||j.status==='complete'||j.status==='superseded'||j.leaseUntil>now||(j.attempts>=3&&j.status==='failed')||(j.nextRetryAt||0)>now)return null;
 const leaseToken=token();await ref.update({data:{status:'running',leaseToken,leaseUntil:now+390000,updatedAt:now}});return {...j,leaseToken,status:'running'};
});}
async function update(id,j,patch,forecastPatch){return db.runTransaction(async tx=>{
 const ref=tx.collection('forecast_jobs').doc(id),current=await get(ref);
 if(!current||current.generationId!==j.generationId||current.leaseToken!==j.leaseToken)return false;
 await ref.update({data:{...patch,updatedAt:Date.now()}});
 const uref=tx.collection('user_state').doc(id),u=await get(uref);
 if(u&&u.forecast&&u.forecast.generationId===j.generationId&&forecastPatch)await uref.update({data:{forecast:{...u.forecast,...forecastPatch}}});
 return true;
});}
async function request(batch,key,model,timeout){
 const prompt=buildSystemPrompt();
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout);
 try{
  const response=await fetch('https://api.deepseek.com/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+key},body:JSON.stringify({model,messages:[{role:'system',content:prompt},{role:'user',content:JSON.stringify({days:batch})}],thinking:{type:'disabled'},response_format:{type:'json_object'},max_tokens:12000,stream:false}),signal:controller.signal});
  if(!response.ok)throw new Error('MODEL_HTTP_'+response.status);
  const raw=await response.json(),choice=raw.choices&&raw.choices[0];if(!choice||choice.finish_reason!=='stop')throw new Error('MODEL_INCOMPLETE');
  const parsed=JSON.parse(choice.message.content);if(!Array.isArray(parsed.days)||parsed.days.length!==batch.length)throw new Error('MODEL_DATE_MISMATCH');
  parsed.days.forEach((item,i)=>{if(item.date!==batch[i].reference_date)throw new Error('MODEL_DATE_MISMATCH');validateResult(item.result,batch[i].facts);});
  return {days:parsed.days,usage:{response_id:raw.id||null,model:raw.model||model,usage:raw.usage||null,completed_at:new Date().toISOString()}};
 }finally{clearTimeout(timer);}
}
async function publish(id,j){return db.runTransaction(async tx=>{
 const ref=tx.collection('forecast_jobs').doc(id),cur=await get(ref);
 if(!cur||cur.generationId!==j.generationId||cur.leaseToken!==j.leaseToken)return false;
 const uref=tx.collection('user_state').doc(id),u=await get(uref);
 if(cur.status==='complete')return true;
 if(!u||sourceHash(ownerSource(u))!==cur.sourceHash){await ref.update({data:{status:'superseded',leaseUntil:0,leaseToken:'',updatedAt:Date.now()}});return false;}
 const readings={...(u.state.readings||{})},meta={...(u.readingMeta||{})},previous={};let changed=0;
 for(const date of cur.dates){
  const exists=Object.prototype.hasOwnProperty.call(readings,date);
  if(date<today()||exists&&(!cur.replaceFuture||date===today()||meta[date]?.source_hash===cur.sourceHash))continue;
  if(!cur.outputs[date])throw new Error('MISSING_DAY');
  if(exists)previous[date]={result:readings[date],meta:meta[date]||null};
  readings[date]=cur.outputs[date];changed++;meta[date]={generation_id:cur.generationId,forecast_as_of:cur.asOf,source_hash:cur.sourceHash,provider:'DeepSeek',prompt_version:VERSION,completed_at:new Date().toISOString()};
 }
 const forecast={...planner.summary(cur),status:'complete',offset:cur.dates.length};
 // Immutable per-generation archive keeps both the new result and replaced future versions.
 const archive=tx.collection('forecast_jobs').doc('result-'+id+'-'+cur.generationId);
 await archive.set({data:{status:'archived',userId:id,generationId:cur.generationId,sourceHash:cur.sourceHash,promptVersion:VERSION,dates:cur.dates,outputs:cur.outputs,previous,usage:cur.usage,completedAt:Date.now()}});
 await uref.update({data:{'state.readings':readings,readingMeta:meta,forecast,revision:(u.revision||0)+(changed?1:0),updatedAt:db.serverDate()}});
 await ref.update({data:{status:'complete',leaseUntil:0,leaseToken:'',updatedAt:Date.now()}});return true;
});}

async function continueJob(id,generationId){await require('./dispatch').dispatchTracked(db,id,generationId);}
exports.main=async(event={})=>{
 const context=cloud.getWXContext();if(context.OPENID&&context.APPID!=='YOUR_WECHAT_APPID')throw new Error('UNAUTHORIZED');
 if(event.action==='inspect'){if(context.OPENID||context.APPID||event.internal!==true)throw new Error('UNAUTHORIZED');return {status:'ready',contractVersion:2,promptVersion:VERSION,enabled:process.env.FORECAST_ENABLED!=='false'};}
 if(process.env.FORECAST_ENABLED==='false')return {status:'paused'};
 if(event.Type==='Timer'&&!context.OPENID)await planner.planPage(db);
 const id=await pick(event,context.OPENID);if(!id)return {status:'idle'};
 await planner.ensure(db,id);
 const j=await claim(id);if(!j)return {status:'busy_or_complete'};
 const key=process.env.DEEPSEEK_API_KEY,model=process.env.DEEPSEEK_MODEL;
 if(!key||!model){await update(id,j,{status:'awaiting_config',leaseUntil:0,leaseToken:''},{status:'awaiting_config'});return {status:'awaiting_config'};}
 const deadline=Date.now()+310000;
 try{
  if(!Array.isArray(j.dates)||!j.dates.length||j.dates.length>32||!j.source||sourceHash(j.source)!==j.sourceHash)throw new Error('INVALID_JOB');
  j.offset=j.offset||0;j.outputs=j.outputs||{};j.usage=j.usage||[];
  for(let n=0;n<4&&j.offset<j.dates.length;n++){
   const left=deadline-Date.now();if(left<25000)break;
   const batch=j.dates.slice(j.offset,j.offset+8).map(d=>validateInput(buildInput(d,j.source,j.asOf)));
   const result=await request(batch,key,model,Math.min(left-10000,240000));
   result.days.forEach(v=>{j.outputs[v.date]=v.result;});j.offset+=batch.length;j.usage.push(result.usage);
   const current=await update(id,j,{outputs:j.outputs,offset:j.offset,usage:j.usage},{status:'running',offset:j.offset});if(!current)return {status:'superseded'};
  }
  if(j.offset===j.dates.length)return {status:await publish(id,j)?'complete':'superseded'};
  if(await update(id,j,{status:'queued',leaseUntil:0,leaseToken:''},{status:'queued',offset:j.offset}))await continueJob(id,j.generationId);
  return {status:'queued',offset:j.offset};
 }catch(error){
  if(Date.now()>deadline-15000){if(await update(id,j,{status:'queued',leaseUntil:0,leaseToken:''},{status:'queued',offset:j.offset||0}))await continueJob(id,j.generationId).catch(()=>{});return {status:'queued',offset:j.offset||0};}
  const attempts=(j.attempts||0)+1;const safeError=/^(MODEL_HTTP_\d+|MODEL_INCOMPLETE|MODEL_DATE_MISMATCH|INVALID_JOB|MISSING_DAY|DISPATCH_UNAVAILABLE)$/.test(error.message||'')?error.message:'GENERATION_FAILED';
  await update(id,j,{status:'failed',attempts,nextRetryAt:Date.now()+Math.min(3600000,60000*Math.pow(2,attempts-1)),leaseUntil:0,leaseToken:'',error:safeError},{status:'failed',offset:j.offset||0});
  return {status:'failed',retryable:attempts<3,error:safeError};
 }
};
