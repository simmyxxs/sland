'use strict';
const object=x=>!!x&&typeof x==='object'&&!Array.isArray(x);
const required=(ok,message)=>{if(!ok)throw new Error(message);};
const exact=(o,keys)=>object(o)&&Object.keys(o).sort().join('|')===keys.slice().sort().join('|');
const length=s=>Array.from(s).length;
const text=(s,max)=>typeof s==='string'&&length(s)>=1&&length(s)<=max;
function validateInput(x){
 required(object(x)&&x.schema_version==='1.0.0','Unsupported input version');
 required(object(x.facts),'facts required');
 for(const k of ['local_date','timezone','actual_menstrual_records','body_season','moon_phase','day_pillar','day_master','luck_pillar','year_pillar','solar_term','context','sleep','felt_energy'])required(object(x.facts[k]),'Missing fact '+k);
 for(const [k,v]of Object.entries(x.facts))required(object(v)&&Object.prototype.hasOwnProperty.call(v,'value')&&typeof v.quality==='string'&&typeof v.source==='string'&&v.source.length>0,'Incomplete fact '+k);
 for(const key of ['reference_date','forecast_as_of'])required(typeof x[key]==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(x[key])&&Number.isFinite(Date.parse(x[key]))&&new Date(x[key]).toISOString().slice(0,10)===x[key],'Invalid '+key);
 required(x.facts.timezone.value==='Asia/Shanghai','Invalid timezone');
 required(Array.isArray(x.facts.actual_menstrual_records.value),'Actual records must be array');
 for(const [key,lo,hi] of [['cycle_length_days',10,100],['bleeding_days',1,30],['ovulation_window_starts_in_days',0,100]]){const v=x.facts[key]&&x.facts[key].value;required(v==null||(typeof v==='number'&&Number.isFinite(v)&&v>=lo&&v<=hi),'Invalid '+key);}
 return x;
}
function validateResult(x,facts){
 required(exact(x,['headline','suggestion','explanation','caveat','fact_vs_interpretation']),'Invalid response keys');
 required(typeof x.headline==='string'&&/^\p{Script=Han}{4}，\p{Script=Han}{4}$/u.test(x.headline),'Invalid headline: four Han characters per clause');required(text(x.suggestion,24),'Invalid suggestion');
 required(x.caveat===null||(typeof x.caveat==='string'&&length(x.caveat)<=100),'Invalid caveat');
 required(Array.isArray(x.explanation)&&x.explanation.length>=1&&x.explanation.length<=3,'Invalid explanation count');
 const ids=v=>required(Array.isArray(v)&&v.length>0&&v.every(k=>typeof k==='string'&&Object.prototype.hasOwnProperty.call(facts,k)),'Unrecognized or missing evidence ID');
 for(const e of x.explanation){required(exact(e,['text','evidence_ids'])&&text(e.text,120),'Invalid explanation');ids(e.evidence_ids);}
 const f=x.fact_vs_interpretation;required(exact(f,['fact_ids','interpretation'])&&text(f.interpretation,160),'Invalid distinction');ids(f.fact_ids);return x;
}
module.exports={validateInput,validateResult};
