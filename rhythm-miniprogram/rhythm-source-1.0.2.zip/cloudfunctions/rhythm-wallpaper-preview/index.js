'use strict';
const crypto=require('crypto');
const cloud=require('wx-server-sdk');
const cloudbase=require('@cloudbase/node-sdk');
const {TYPES,VERSION,buildPreviewPrompt}=require('./prompt');
const {downloadImage}=require('./download');
cloud.init({env:cloud.DYNAMIC_CURRENT_ENV});
const app=cloudbase.init({env:process.env.ENV_ID||'YOUR_CLOUDBASE_ENV_ID'}),db=cloud.database();
const MODEL='HY-Image-3.0-Plus-4090-Tob-v1.0';
const ACTION='preview-v2-ten-types',ROOT='wallpaper-previews/v2/';
const RECOVERY_TYPES=new Set(['yang-fire','yin-fire','yang-metal']);
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const safeError=e=>/^(IMAGE_[A-Z_]+|PREVIEW_[A-Z_]+)$/.test(e&&e.message||'')?e.message:'PREVIEW_GENERATION_FAILED';
async function get(ref){try{return (await ref.get()).data;}catch(e){if(e.errCode===-502001||/not exist|not found|不存在/i.test(e.errMsg||e.message||''))return null;throw e;}}
function authorize(event){
 const context=cloud.getWXContext();if(context.OPENID||context.APPID)throw new Error('UNAUTHORIZED');
 if(event.internal!==true||event.action!==ACTION)throw new Error('UNAUTHORIZED');
 const expected=process.env.WALLPAPER_PREVIEW_TOKEN;
 if(expected){const supplied=event.token;if(typeof supplied!=='string'||Buffer.byteLength(supplied)!==Buffer.byteLength(expected)||!crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(expected)))throw new Error('UNAUTHORIZED');}
}
const refFor=(tx,kind)=>tx.collection('wallpaper_jobs').doc('preview-v2-'+kind);
function providerDiagnostic(error,stage){
 const clean=(value,max=128)=>typeof value==='string'&&value.length<=max&&/^[A-Za-z0-9_.|-]+$/.test(value)?value:null;
 const code=clean(String(error&&error.code||''),96);
 const status=Number(error&&(error.statusCode||error.status)||(/^\d{3}$/.test(code||'')?code:0));
 return {stage,providerCode:code,requestId:clean(error&&error.requestId),httpStatus:Number.isInteger(status)&&status>=100&&status<=599?status:null,exceptionType:clean(error&&error.name,64)};
}
async function claim(kind,design,retryFailedOnce){return db.runTransaction(async tx=>{
 const ref=refFor(tx,kind),old=await get(ref),now=Date.now(),promptHash=hash(design.prompt);
 if(old&&old.status==='complete'&&old.fileId)return {skip:'already_complete',fileId:old.fileId};
 if(old&&(old.promptVersion!==VERSION||old.promptHash!==promptHash))return {skip:'version_conflict'};
 if(old&&old.leaseUntil>now)return {skip:'busy'};
 const allowRetry=!!(retryFailedOnce&&RECOVERY_TYPES.has(kind)&&old&&old.status==='failed'&&!old.imageUrl&&(old.adminRetryCount||0)<1);
 if(old&&old.generationRequested&&!old.imageUrl&&!allowRetry)return {skip:'uncertain_previous_request'};
 const next=Object.assign({},old||{kind,generationId:crypto.randomUUID(),promptVersion:VERSION,promptHash,reference:'v5',provider:'tencent-cloudbase-hunyuan',model:MODEL,stem:design.ganzhi,element:design.element,generationRequested:false},{status:'running',leaseToken:crypto.randomUUID(),leaseUntil:now+960000,updatedAt:now});
 if(allowRetry){next.generationRequested=false;next.adminRetryCount=(old.adminRetryCount||0)+1;next.adminRetryAt=new Date().toISOString();}
 delete next._id;delete next._openid;await ref.set({data:next});return next;
});}
async function patch(kind,job,data){return db.runTransaction(async tx=>{const ref=refFor(tx,kind),current=await get(ref);if(!current||current.generationId!==job.generationId||current.leaseToken!==job.leaseToken)return false;await ref.update({data:{...data,updatedAt:Date.now()}});return true;});}
function jpeg(buffer){
 if(buffer[0]===255&&buffer[1]===216&&buffer[2]===255)return buffer;
 if(buffer.length<24||buffer.toString('hex',0,8)!=='89504e470d0a1a0a')throw new Error('IMAGE_FORMAT_INVALID');
 const width=buffer.readUInt32BE(16),height=buffer.readUInt32BE(20);if(!width||!height||width*height>16777216)throw new Error('IMAGE_DIMENSIONS_INVALID');
 const png=require('pngjs').PNG.sync.read(buffer,{checkCRC:true});for(let i=0;i<png.data.length;i+=4){const a=png.data[i+3]/255;png.data[i]=Math.round(png.data[i]*a+247*(1-a));png.data[i+1]=Math.round(png.data[i+1]*a+246*(1-a));png.data[i+2]=Math.round(png.data[i+2]*a+242*(1-a));png.data[i+3]=255;}
 return require('jpeg-js').encode({data:png.data,width:png.width,height:png.height},82).data;
}
async function generateOne(kind,deadline,retryFailedOnce){
 if(Date.now()>deadline-120000)return {kind,status:'deferred'};
 const design=buildPreviewPrompt(kind);let job,stage='claim';
 try{
  try{job=await claim(kind,design,retryFailedOnce);}catch(e){throw new Error('PREVIEW_CLAIM_FAILED');}
  if(job.skip)return {kind,status:job.skip==='already_complete'?'complete':'skipped',reason:job.skip,...(job.fileId?{fileId:job.fileId}:{})};
  let imageUrl=job.imageUrl;
  if(!imageUrl){
   if(!await patch(kind,job,{generationRequested:true,status:'generating'}))return {kind,status:'superseded'};
   stage='generate';
   const result=await app.ai().createImageModel('hunyuan-image').generateImage({model:MODEL,prompt:design.prompt,size:'720x1280',revise:{value:true}});
   imageUrl=result&&result.data&&result.data[0]&&result.data[0].url;if(typeof imageUrl!=='string')throw new Error('IMAGE_RESPONSE_INVALID');
   let imageHost;try{imageHost=new URL(imageUrl).hostname;}catch(e){throw new Error('IMAGE_URL_INVALID');}
   if(!await patch(kind,job,{imageUrl,imageHost,imageReceivedAt:Date.now(),status:'generated'}))return {kind,status:'superseded'};
  }
  stage='download';
  const downloaded=await downloadImage(imageUrl),image=jpeg(downloaded.buffer||downloaded);
  stage='upload';
  const uploaded=await app.uploadFile({cloudPath:ROOT+kind+'.jpg',fileContent:image});if(!uploaded.fileID)throw new Error('IMAGE_UPLOAD_FAILED');
  stage='finalize';
  const saved=await patch(kind,job,{status:'complete',fileId:uploaded.fileID,kind,promptVersion:VERSION,provider:'tencent-cloudbase-hunyuan',model:MODEL,reference:'v5',stem:design.ganzhi,element:design.element,size:'720x1280',imageUrl:db.command.remove(),leaseUntil:0,leaseToken:'',completedAt:new Date().toISOString()});
  return {kind,status:saved?'complete':'superseded',...(saved?{fileId:uploaded.fileID}:{})};
 }catch(error){const code=safeError(error),extra={providerDiagnostic:providerDiagnostic(error,stage),...(error&&error.imageDiagnostic?{imageDiagnostic:error.imageDiagnostic}:{})};if(job&&!job.skip)await patch(kind,job,{status:'failed',error:code,leaseUntil:0,leaseToken:'',...extra}).catch(()=>{});return {kind,status:'failed',error:code,...extra};}
}
exports.main=async(event={})=>{
 authorize(event);if(process.env.WALLPAPER_PREVIEW_ENABLED!=='true')return {status:'disabled',version:VERSION};
 const deadline=Date.now()+800000,results=new Array(TYPES.length);let cursor=0;
 async function lane(){while(cursor<TYPES.length){const index=cursor++;results[index]=await generateOne(TYPES[index],deadline,event.retryFailedOnce===true);}}
 await Promise.all([lane(),lane()]);
 const complete=results.filter(r=>r.status==='complete').length;
 return {status:complete===TYPES.length?'complete':'partial',version:VERSION,count:TYPES.length,complete,results};
};
