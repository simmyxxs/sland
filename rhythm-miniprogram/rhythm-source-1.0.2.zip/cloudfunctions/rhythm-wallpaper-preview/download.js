'use strict';
const https=require('https'),dns=require('dns').promises,net=require('net');
const MAX_BYTES=20*1024*1024,TIMEOUT_MS=60000;
function publicIP(ip){
 const type=net.isIP(ip);
 if(type===4){const a=ip.split('.').map(Number),[x,y,z]=a;
  if(x===0||x===10||x===127||x>=224||x===100&&y>=64&&y<=127||x===169&&y===254||x===172&&y>=16&&y<=31||x===192&&y===168)return false;
  if(x===192&&y===0&&(z===0||z===2)||x===192&&y===88&&z===99||x===198&&(y===18||y===19)||x===198&&y===51&&z===100||x===203&&y===0&&z===113)return false;
  return true;
 }
 if(type===6){
  // 只允许原生全球单播 2000::/3；拒绝 IPv4 映射、6to4、Teredo 及文档网段。
  const parts=ip.split(':'),first=parseInt(parts[0],16),second=parseInt(parts[1]||'0',16);
  return first>=0x2000&&first<=0x3fff&&first!==0x2002&&first!==0x3fff&&!(first===0x2001&&(second<0x200||second===0xdb8));
 }
 return false;
}
function allowedHost(host){
 const configured=(process.env.WALLPAPER_IMAGE_HOSTS||'hunyuan.qcloud.com').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);
 // 仅精确域名，不支持星号、URL、端口或 IP 地址。
 return configured.some(h=>/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/.test(h)&&h===host);
}
async function checkedURL(value,deadline){
 let url;try{url=new URL(value);}catch(e){throw new Error('IMAGE_URL_INVALID');}
 if(url.protocol!=='https:'||url.username||url.password||url.port&&url.port!=='443'||!allowedHost(url.hostname)||net.isIP(url.hostname))throw new Error('IMAGE_HOST_NOT_ALLOWED');
 const addresses=await timed(dns.lookup(url.hostname,{all:true,verbatim:true}),deadline);
 if(!addresses.length||addresses.some(a=>!publicIP(a.address)))throw new Error('IMAGE_ADDRESS_NOT_PUBLIC');
 return {url,address:addresses[0]};
}
function timed(promise,deadline){return new Promise((resolve,reject)=>{const remaining=deadline-Date.now();if(remaining<=0)return reject(new Error('IMAGE_TIMEOUT'));const timer=setTimeout(()=>reject(new Error('IMAGE_TIMEOUT')),remaining);promise.then(v=>{clearTimeout(timer);resolve(v);},e=>{clearTimeout(timer);reject(e);});});}
function fetchOnce(url,address,deadline){return new Promise((resolve,reject)=>{
 const remaining=deadline-Date.now();if(remaining<=0)return reject(new Error('IMAGE_TIMEOUT'));
 let complete=false;const finish=(err,value)=>{if(complete)return;complete=true;clearTimeout(timer);err?reject(err):resolve(value);};
 const req=https.get(url,{agent:false,lookup:(_host,options,cb)=>options&&options.all?cb(null,[address]):cb(null,address.address,address.family),headers:{Accept:'image/jpeg,image/png'},rejectUnauthorized:true},response=>{
  const code=response.statusCode;
  if([301,302,303,307,308].includes(code)){const location=response.headers.location;response.destroy();if(!location)return finish(new Error('IMAGE_REDIRECT_INVALID'));let target;try{target=new URL(location,url).href;}catch(e){return finish(new Error('IMAGE_REDIRECT_INVALID'));}return finish(null,{redirect:target});}
  if(code!==200){response.destroy();return finish(new Error('IMAGE_HTTP_ERROR'));}
  const mime=String(response.headers['content-type']||'').split(';')[0].trim().toLowerCase();
  if(!['image/jpeg','image/png','image/webp'].includes(mime)){response.destroy();return finish(new Error('IMAGE_TYPE_INVALID'));}
  const declared=response.headers['content-length'];if(declared&&(!/^\d+$/.test(declared)||Number(declared)>MAX_BYTES)){response.destroy();return finish(new Error('IMAGE_TOO_LARGE'));}
  const chunks=[];let bytes=0;response.on('data',chunk=>{bytes+=chunk.length;if(bytes>MAX_BYTES){response.destroy();return finish(new Error('IMAGE_TOO_LARGE'));}chunks.push(chunk);});
  response.on('error',()=>finish(new Error('IMAGE_DOWNLOAD_FAILED')));response.on('aborted',()=>finish(new Error('IMAGE_DOWNLOAD_FAILED')));
  response.on('end',()=>{const buffer=Buffer.concat(chunks);const png=buffer.length>=8&&buffer.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));const jpeg=buffer.length>=3&&buffer[0]===255&&buffer[1]===216&&buffer[2]===255;
   const webp=buffer.length>=12&&buffer.toString('ascii',0,4)==='RIFF'&&buffer.toString('ascii',8,12)==='WEBP';
   const format=png?'png':jpeg?'jpeg':webp?'webp':'unknown',diagnostic={contentType:mime,prefixHex:buffer.subarray(0,16).toString('hex'),bytes:buffer.length,format};
   if(!png&&!jpeg||webp){const error=new Error(webp?'IMAGE_WEBP_UNSUPPORTED':'IMAGE_MAGIC_INVALID');error.imageDiagnostic=diagnostic;return finish(error);}
   finish(null,{buffer,mime,format,extension:png?'png':'jpg',diagnostic});
  });
 });
 const timer=setTimeout(()=>{req.destroy();finish(new Error('IMAGE_TIMEOUT'));},remaining);
 req.on('error',()=>finish(new Error('IMAGE_DOWNLOAD_FAILED')));
});}
// 仅传入服务端生成 SDK 原始响应中的 res.data[0].url，不能接收 event.url。
async function downloadImage(modelURL){
 const deadline=Date.now()+TIMEOUT_MS;let current=modelURL;
 for(let hop=0;hop<=2;hop++){
  const {url,address}=await checkedURL(current,deadline),result=await fetchOnce(url,address,deadline);
  if(!result.redirect)return result;
  if(hop===2)throw new Error('IMAGE_TOO_MANY_REDIRECTS');current=result.redirect;
 }
 throw new Error('IMAGE_DOWNLOAD_FAILED');
}
module.exports={downloadImage};
