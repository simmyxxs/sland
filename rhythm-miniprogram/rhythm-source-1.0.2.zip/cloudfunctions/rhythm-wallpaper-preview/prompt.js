'use strict';
const {Solar}=require('./vendor/lunar');
const VERSION='wallpaper-v2-v5-reference';
const TYPES=Object.freeze(['yang-wood','yin-wood','yang-fire','yin-fire','yang-earth','yin-earth','yang-metal','yin-metal','yang-water','yin-water']);
const templates=[
 ['wood','甲','阳木','低机位仰拍一棵真实高大乔木，灰褐树干从画面下部向上挺立，粗细枝条自然分叉，深绿树冠包围顶部，叶隙露出少量灰蓝天空。树皮粗粝，深绿叶片保留阴影，林间散射天光，真实森林的纵深与重量；下部选择枝叶较疏、树皮较均匀的暗部。'],
 ['wood','乙','阴木','近摄柔枝上垂落的嫩叶，枝叶在上方和一侧形成自然弧线，黄绿叶片被逆光照透，叶脉清楚，背景是深浅绿色的柔和散景与零星水滴光点。浅景深，自然细腻，保留明亮黄绿与深绿暗部的真实反差；下部以较安静的绿色虚化背景承接。'],
 ['fire','丙','阳火','真实海面日出或日落摄影，太阳圆盘接近地平线和低云，金橙色天空占上方，暖金光穿透云边，海面细浪带出金色反光，下方海水保持深棕灰阴影。阳光饱满而真实，保留金橙光色和自然亮暗，地平线平稳，下部水纹疏朗而不过曝。'],
 ['fire','丁','阴火','近摄一盏点亮的暖灯，灯泡与深色金属灯罩置于画面上方一侧，琥珀色灯光落在深棕暖色墙面，附近少量深绿叶影。灯丝与玻璃有真实高光，墙面有细微材质，暖暗室内摄影，保留琥珀与深棕的层次；下方是安静连续的暖棕墙面。'],
 ['earth','戊','阳土','低机位拍摄厚重的金赭色砂岩古堡或城墙，粗粝石块、城垛与层叠墙面具有真实结构，建筑沉稳地延伸在画面中下部，上方是自然灰蓝天空与轻云。自然日光照亮金黄赭色石材，墙体阴影保留棕褐深度；下部选择结构简洁的大块石面，避免杂乱细节。'],
 ['earth','己','阴土','真实雾沙沙丘摄影，远处沙丘被细雾轻轻遮住，米色、粉棕与暖褐色丘线一层层舒缓铺展，近处沙纹细密而真实。上方空气朦胧，下方沙丘保留深棕阴影，整体柔和但不抹平亮暗，保留原本米粉棕色调；下部丘面线条平静、纹理疏淡。'],
 ['metal','庚','阳金','真实铁匠工具静物摄影，灰黑色铁砧稳置于旧木墩，一旁有少量铁锤或工具，后方是苔绿草地与旧作坊边缘。铁砧边缘有磨亮银灰痕迹，表面粗粝带旧锈，木纹裂痕清楚，柔和自然侧光，保留灰黑金属、苔绿和暗褐原色；下方木墩与暗部构成较平静区域。'],
 ['metal','辛','阴金','近距离真实首饰静物摄影，一条纤细浅金项链自然搭在米白织物褶皱上，链条精巧、弧线轻盈，金属只呈细小真实反光，织物纤维与褶皱有清楚质感。柔和窗光，米白、浅金与灰褐阴影，浅景深而不是商品海报；项链偏上侧，下方保留连续安静的织物面。'],
 ['water','壬','阳水','真实开阔海面摄影，湖蓝与青绿色海水延伸到平直地平线，远处是淡蓝灰天空，近处轻浪与稀疏白色泡沫透明可见。保留清透湖蓝、青绿海水和自然深浅层次，不改成灰白或淡粉，晴天自然光、水面真实反射；下方较平稳的浅浪区域细节不过密。'],
 ['water','癸','阴水','真实幽深林溪摄影，窄溪在深绿树林与苔石间流过，一段深色倒木横过画面中部，细碎阳光穿过林冠。溪水呈蓝黑与深青倒影，水面有少量银亮闪点，近处苔藓和湿木清楚可见，保留深绿、蓝黑及真实阴影；下部以平静暗水与阴影承接，避免密集亮点。']
];
function compose(index,variation,ganzhi){
 const [element,stem,label,scene]=templates[index];
 const freshness=variation.date?`以公用日期${variation.date}和当日${ganzhi}作为新构图变化标记，改变合理的视角、细节与光影。`:'生成这一类别的一张独立新构图。';
 const prompt=`竖屏真实摄影壁纸，${stem}${label}，参照已确认v5的题材、自然原色与原有明暗关系。${scene}${freshness}借鉴视觉方向，不机械复制参考图的具体布局。服务于白色UI叠加，下方文字覆盖区域保持相对平静，但不强加白色留白，不统一提亮、不统一雾化、不套米白滤镜。保留本类别明确描述的主体及器物，不额外拼入其他类别的物件。真实材质与光线，无人物、无文字排版、无标志、无额外人工水印（保留平台自动附加的AI标识）、无玄学符号、无插画感；不画月亮图标或几何节律图形。`;
 if(Array.from(prompt).length>500)throw new Error('PROMPT_TOO_LONG');
 return {prompt,ganzhi,element,variation:{...variation,kind:TYPES[index],version:VERSION,stem,reference:'v5'}};
}
function buildPreviewPrompt(kind){
 const index=TYPES.indexOf(kind);if(index<0)throw new Error('INVALID_WALLPAPER_KIND');
 return compose(index,{preview:true},templates[index][1]);
}
function buildPrompt(date){
 if(typeof date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date)throw new Error('INVALID_DATE');
 const [y,m,d]=date.split('-').map(Number),ganzhi=Solar.fromYmdHms(y,m,d,12,0,0).getLunar().getDayInGanZhi();
 const a='甲乙丙丁戊己庚辛壬癸'.indexOf(ganzhi[0]),b='子丑寅卯辰巳午未申酉戌亥'.indexOf(ganzhi[1]);
 if(a<0||b<0||a%2!==b%2)throw new Error('INVALID_GANZHI');
 return compose(a,{date,branch:ganzhi[1]},ganzhi);
}
module.exports={buildPrompt,buildPreviewPrompt,TYPES,VERSION};
