'use strict';
const crypto=require('crypto');
const https=require('https');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const hmac=(key,s)=>crypto.createHmac('sha256',key).update(s).digest();
// SCF Invoke(Event) queues the worker before this short API function returns.
// Uses the function's temporary role credentials, never a customer API key.
function dispatch(userId){
 if(process.env.FORECAST_ASYNC_ENABLED!=='true')return Promise.resolve({status:'disabled',error:'ASYNC_DISABLED'});
 const id=process.env.TENCENTCLOUD_SECRETID,key=process.env.TENCENTCLOUD_SECRETKEY,token=process.env.TENCENTCLOUD_SESSIONTOKEN;
 if(!id||!key||!token)return Promise.resolve({status:'missing_credentials',error:'RUNTIME_CREDENTIALS_MISSING'});
 const host='scf.tencentcloudapi.com',service='scf',timestamp=Math.floor(Date.now()/1000),date=new Date(timestamp*1000).toISOString().slice(0,10);
 const namespace=process.env.FORECAST_NAMESPACE||process.env.SCF_NAMESPACE||'YOUR_CLOUDBASE_ENV_ID';
 const body=JSON.stringify({FunctionName:'rhythm-forecast',Namespace:namespace,InvocationType:'Event',ClientContext:JSON.stringify({internal:true,userId})});
 const contentType='application/json; charset=utf-8',signedHeaders='content-type;host',canonicalHeaders='content-type:'+contentType+'\nhost:'+host+'\n';
 const canonical=['POST','/','',canonicalHeaders,signedHeaders,hash(body)].join('\n'),scope=date+'/'+service+'/tc3_request',toSign=['TC3-HMAC-SHA256',timestamp,scope,hash(canonical)].join('\n');
 const signature=crypto.createHmac('sha256',hmac(hmac(hmac('TC3'+key,date),service),'tc3_request')).update(toSign).digest('hex');
 const headers={'Content-Type':contentType,Host:host,'X-TC-Action':'Invoke','X-TC-Version':'2018-04-16','X-TC-Timestamp':timestamp,'X-TC-Region':'ap-shanghai','X-TC-Token':token,Authorization:'TC3-HMAC-SHA256 Credential='+id+'/'+scope+', SignedHeaders='+signedHeaders+', Signature='+signature};
 const safeCode=code=>typeof code==='string'&&/^[A-Za-z][A-Za-z0-9_.-]{0,100}$/.test(code)?code:'SCF_DISPATCH_FAILED';
 return new Promise(resolve=>{const req=https.request({hostname:host,path:'/',method:'POST',headers,timeout:5000},res=>{let raw='';res.on('data',part=>{raw+=part;});res.on('end',()=>{try{const out=JSON.parse(raw);if(!out.Response)return resolve({status:'error',error:'INVALID_SCF_RESPONSE'});if(out.Response.Error)return resolve({status:'error',error:safeCode(out.Response.Error.Code)});if(res.statusCode!==200)return resolve({status:'error',error:'SCF_HTTP_'+res.statusCode});resolve({status:'accepted',error:null});}catch(e){resolve({status:'error',error:'INVALID_SCF_RESPONSE'});}});});req.on('timeout',()=>req.destroy(new Error('FORECAST_DISPATCH_TIMEOUT')));req.on('error',error=>resolve({status:'error',error:error&&error.message==='FORECAST_DISPATCH_TIMEOUT'?'SCF_DISPATCH_TIMEOUT':'SCF_NETWORK_ERROR'}));req.end(body);});
}
async function dispatchTracked(db,userId,generationId){
 let result;try{result=await dispatch(userId);}catch(e){result={status:'error',error:'SCF_DISPATCH_FAILED'};}
 const at=Date.now();
 try{await db.runTransaction(async tx=>{const ref=tx.collection('forecast_jobs').doc(userId),current=(await ref.get()).data;if(!current||generationId&&current.generationId!==generationId)return;await ref.update({data:{lastDispatch:{at,status:result.status},lastDispatchError:result.error||null}});});}catch(e){}
 return result;
}
module.exports={dispatch,dispatchTracked};
