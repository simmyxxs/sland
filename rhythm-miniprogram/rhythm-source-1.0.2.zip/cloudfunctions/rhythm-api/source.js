'use strict';
const crypto=require('crypto');
const PERSONAL_KEYS=Object.freeze(['birth_pillars','day_master','luck_pillar','context','sleep','felt_energy']);
const object=x=>!!x&&typeof x==='object'&&!Array.isArray(x);
// Stable recursive key ordering, retaining only JSON values; never add runtime dates or outputs.
function stable(value){
 if(value===null||typeof value==='string'||typeof value==='boolean')return value;
 if(typeof value==='number')return Number.isFinite(value)?value:null;
 if(Array.isArray(value))return value.map(v=>stable(v)===undefined?null:stable(v));
 if(object(value)){const out={};for(const key of Object.keys(value).sort())if(!['__proto__','prototype','constructor'].includes(key)){const v=stable(value[key]);if(v!==undefined)out[key]=v;}return out;}
 return undefined;
}
function canonicalSource(state={}){
 const periods=(Array.isArray(state.periods)?state.periods:[]).map(p=>({start_date:p.start_date,end_date:p.end_date||null})).sort((a,b)=>String(b.start_date).localeCompare(String(a.start_date))||String(a.end_date).localeCompare(String(b.end_date)));
 const feedbacks={};for(const key of Object.keys(object(state.feedbacks)?state.feedbacks:{}).sort()){const f=state.feedbacks[key];if(object(f))feedbacks[key]={note:typeof f.note==='string'?f.note:'',prediction_accuracy:Number.isInteger(f.prediction_accuracy)?f.prediction_accuracy:null};}
 const birth=object(state.birth)&&state.birth.date?{date:state.birth.date,time:state.birth.unknown?'':state.birth.time||'',unknown:!!state.birth.unknown,place:state.birth.place||''}:{};
 const manualChart=object(state.manualChart)&&state.manualChart.day?{year:state.manualChart.year||'',month:state.manualChart.month||'',day:state.manualChart.day,time:state.manualChart.unknown?'':state.manualChart.time||'',unknown:!!state.manualChart.unknown}:{};
 const personalFacts={};for(const key of PERSONAL_KEYS)if(object(state.personalFacts)&&Object.prototype.hasOwnProperty.call(state.personalFacts,key))personalFacts[key]=stable(state.personalFacts[key]);
 return stable({periods,feedbacks,birth,manualChart,chartSource:state.chartSource==='manual'?'manual':'date',cycleLength:Number.isFinite(state.cycleLength)?state.cycleLength:null,personalFacts});
}
function ownerSource(doc={}){const state=object(doc.state)?doc.state:{};return canonicalSource({...state,personalFacts:object(doc.personalFacts)?doc.personalFacts:state.personalFacts});}
function sourceHash(state){return crypto.createHash('sha256').update(JSON.stringify(canonicalSource(state))).digest('hex');}
module.exports={canonicalSource,sourceOf:canonicalSource,sourceHash,ownerSource,PERSONAL_KEYS};
