'use strict';
const crypto=require('crypto');
const {ownerSource,sourceHash}=require('./source');
const PROMPT_VERSION='rhythm-copy-v2-four-by-four';
const today=()=>new Date(Date.now()+28800000).toISOString().slice(0,10);
function datesFor(start){const [y,m,d]=start.split('-').map(Number),lastDay=new Date(Date.UTC(y,m+1,0)).getUTCDate(),until=Date.UTC(y,m,Math.min(d,lastDay)),out=[];for(let t=Date.UTC(y,m-1,d);t<until;t+=86400000)out.push(new Date(t).toISOString().slice(0,10));return out;}
async function get(ref){try{return (await ref.get()).data;}catch(e){if(e.errCode===-502001||/not exist|not found|不存在/i.test(e.errMsg||e.message||''))return null;throw e;}}
function summary(j){return j?{generationId:j.generationId,status:j.status,start_date:j.dates[0],end_date:j.dates[j.dates.length-1],offset:j.offset,count:j.dates.length}:null;}
async function ensure(db,userId,options={}){
 if(process.env.FORECAST_ENABLED==='false')return null;
 return db.runTransaction(async tx=>{
  const userRef=tx.collection('user_state').doc(userId),user=await get(userRef);if(!user){const orphan=tx.collection('forecast_jobs').doc(userId),old=await get(orphan);if(old)await orphan.update({data:{status:'superseded',leaseToken:'',leaseUntil:0}});return null;}
  const source=ownerSource(user),hash=sourceHash(source),jobRef=tx.collection('forecast_jobs').doc(userId),job=await get(jobRef),start=options.today||today();
  const active=job&&['queued','running','failed','awaiting_config'].includes(job.status)&&job.contractVersion===2&&job.promptVersion===PROMPT_VERSION&&job.sourceHash===hash;
  if(active)return job;
  // Old jobs predate the stable-source contract: retire without publishing their outputs.
  if(job&&(job.contractVersion!==2||job.promptVersion!==PROMPT_VERSION)&&job.status!=='complete')await jobRef.update({data:{status:'superseded',leaseToken:'',leaseUntil:0}});
  const changed=!!(options.sourceChanged||user.forecastSourceHash&&user.forecastSourceHash!==hash||user.forecastInvalidated===hash);
  const readings=user.state.readings||{},meta=user.readingMeta||{};
  const dates=datesFor(start).filter(d=>!Object.prototype.hasOwnProperty.call(readings,d)||(changed&&d>start&&meta[d]?.source_hash!==hash));
  const base={sourceHash:hash,forecastSourceHash:hash,sourceRevision:user.sourceRevision||0,forecastInvalidated:'',nextForecastDate:start};
  if(!dates.length){if(user.forecastSourceHash!==hash||user.forecastInvalidated||job&&job.status!=='complete')await userRef.update({data:{...base,...(job?{forecast:{...summary(job),status:'complete'}}:{})}});return null;}
  const next={contractVersion:2,promptVersion:PROMPT_VERSION,userId,generationId:crypto.randomUUID(),sourceHash:hash,source,sourceRevision:user.sourceRevision||0,asOf:start,dates,replaceFuture:changed,status:'queued',offset:0,outputs:{},usage:[],attempts:0,leaseUntil:0,leaseToken:'',updatedAt:Date.now()};
  await jobRef.set({data:next});await userRef.update({data:{...base,forecast:summary(next)}});return next;
 });
}
// _id has a built-in index. A persistent cursor gives every owner a turn; no first-page starvation.
async function planPage(db){
 const ref=db.collection('forecast_jobs').doc('_planner_cursor'),saved=await get(ref);let cursor=saved&&saved.cursor||'',count=0;
 for(let page=0;page<4;page++){
  let query=db.collection('user_state').orderBy('_id','asc');if(cursor)query=query.where({_id:db.command.gt(cursor)});
  const result=await query.limit(25).get();if(!result.data.length){cursor='';break;}
  for(const user of result.data){await ensure(db,user._id);cursor=user._id;count++;}
  if(result.data.length<25){cursor='';break;}
 }
 await ref.set({data:{cursor,updatedAt:Date.now()}});return count;
}
module.exports={ensure,planPage,summary,datesFor,today,get};
