'use strict';
const cloud = require('wx-server-sdk');
const crypto = require('crypto');
const forecast = require('./forecast');
const {ownerSource,sourceHash}=require('./source');
cloud.init({env: cloud.DYNAMIC_CURRENT_ENV});
const db = cloud.database();
const today = () => new Date(Date.now()+28800000).toISOString().slice(0,10);
const empty = () => ({periods:[],feedbacks:{},birth:{},readings:{},cycleLength:null,manualChart:{},chartSource:'date'});
const fail = message => {throw new Error(message);};
const own = (o,k) => Object.prototype.hasOwnProperty.call(o,k);
const object = v => v && typeof v==='object' && !Array.isArray(v);
function date(v){return typeof v==='string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && Number.isFinite(Date.parse(v+'T00:00:00Z')) && new Date(v+'T00:00:00Z').toISOString().slice(0,10)===v;}
function recordDate(v){if(!date(v)||v<'1900-01-01'||v>today())fail('INVALID_DATE');return v;}
function text(v,max){if(typeof v!=='string'||v.length>max)fail('INVALID_TEXT');return v;}
function profile(key,v){
 if(key==='cycleLength'){if(v===null)return null;if(!Number.isInteger(v)||v<15||v>90)fail('INVALID_CYCLE');return v;}
 if(key==='chartSource'){if(v!=='date'&&v!=='manual')fail('INVALID_SOURCE');return v;}
 if(!object(v))fail('INVALID_PROFILE');
 if(key==='birth'){if(!Object.keys(v).length)return {};recordDate(v.date);if(typeof v.unknown!=='boolean')fail('INVALID_BIRTH');const time=v.time||'';if(time&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))fail('INVALID_TIME');if(!v.unknown&&!time)fail('MISSING_TIME');return {date:v.date,time,unknown:v.unknown,place:text(v.place||'',80)};}
 if(key==='manualChart'){if(!Object.keys(v).length)return {};if(typeof v.unknown!=='boolean')fail('INVALID_CHART');const out={unknown:v.unknown};for(const k of ['year','month','day','time']){const s=v[k]||'';if(k==='time'&&v.unknown){out[k]='';continue;}const a='甲乙丙丁戊己庚辛壬癸'.indexOf(s[0]),b='子丑寅卯辰巳午未申酉戌亥'.indexOf(s[1]);if(s.length!==2||a<0||b<0||a%2!==b%2)fail('INVALID_CHART');out[k]=s;}return out;}
 fail('INVALID_PROFILE_KEY');
}
function valueFor(kind,key,v){
 if(kind==='profile')return profile(key,v);
 recordDate(key);
 if(v===null)return null;
 if(!object(v))fail('INVALID_VALUE');
 if(kind==='period'){if(v.start_date!==key)fail('PERIOD_KEY_MISMATCH');recordDate(v.start_date);if(v.end_date){recordDate(v.end_date);if(v.end_date<key)fail('INVALID_PERIOD');}return {start_date:key,end_date:v.end_date||null};}
 if(kind==='feedback'){const n=v.prediction_accuracy;if(n!==null&&n!==undefined&&(!Number.isInteger(n)||n<0||n>10))fail('INVALID_SCORE');return {prediction_accuracy:n==null?null:n,note:text(v.note||'',10000)};}
 fail('INVALID_KIND');
}
function apply(state,kind,key,v){
 if(kind==='profile'){state[key]=v;return;}
 if(kind==='feedback'){if(v===null)delete state.feedbacks[key];else state.feedbacks[key]=v;return;}
 state.periods=state.periods.filter(p=>p.start_date!==key);if(v)state.periods.push(v);state.periods.sort((a,b)=>b.start_date.localeCompare(a.start_date));
}
function checkPeriods(state){const p=state.periods.slice().sort((a,b)=>a.start_date.localeCompare(b.start_date));if(p.length>2000)fail('TOO_MANY_PERIODS');for(let i=1;i<p.length;i++)if((p[i-1].end_date||today())>=p[i].start_date)fail('OVERLAPPING_PERIODS');}
async function get(ref){try{return (await ref.get()).data;}catch(e){if(e.errCode===-502001||/not exist|not found|不存在/i.test(e.errMsg||e.message||''))return null;throw e;}}
function output(doc){return {state:doc?doc.state:empty(),revision:doc?doc.revision:0,versions:doc?doc.versions:{},forecast:doc&&doc.forecast||null};}
exports.main=async event=>{
 const context=cloud.getWXContext();const owner=context.OPENID;
 if(!owner||context.APPID!=='YOUR_WECHAT_APPID')fail('UNAUTHORIZED');
 const legacyOwner=!!process.env.LEGACY_OWNER_OPENID&&process.env.LEGACY_OWNER_OPENID===owner;
 const id=crypto.createHash('sha256').update(owner).digest('hex');
 const ref=db.collection('user_state').doc(id);const action=event&&event.action;
 if(action==='bootstrap'){
  let doc=await get(ref);if(!doc){doc=await db.runTransaction(async tx=>{const r=tx.collection('user_state').doc(id),existing=await get(r);if(existing)return existing;const initial={owner,state:empty(),revision:0,versions:{},lastOperations:[],updatedAt:db.serverDate()};await r.set({data:initial});return {...initial,_created:true};});if(doc._created){await forecast.ensure(db,id);doc=await get(ref);}}const dateKey=today();const wall=await get(db.collection('wallpapers').doc(dateKey));
  return {...output(doc),identity:owner,legacyOwner,wallpaper:require('./wallpaper').select(dateKey,wall)};
 }
 if(action==='dispatchForecast'){const job=await get(db.collection('forecast_jobs').doc(id));if(!job)return {status:'no_job',error:null};return require('./dispatch').dispatchTracked(db,id,job.generationId);}
 if(action!=='mutate'&&action!=='importLegacy')fail('INVALID_ACTION');
 if(action==='importLegacy'&&!legacyOwner)fail('LEGACY_IMPORT_DISABLED');
 const response=await db.runTransaction(async tx=>{
  const docRef=tx.collection('user_state').doc(id);const saved=await get(docRef);
  const doc=saved||{state:empty(),revision:0,versions:{},lastOperations:[]};
  const state=JSON.parse(JSON.stringify(doc.state));const versions={...doc.versions};const applied=[],conflicts=[];
  const last=(doc.lastOperations||[]).slice();
  if(action==='importLegacy'){
   if(saved&&(saved.legacyImported||saved.revision!==0))return {...output(saved),applied,conflicts,skipped:true,legacyImported:!!saved.legacyImported};
   const src=event.state;if(!object(src)||JSON.stringify(src).length>500000)fail('INVALID_LEGACY');
   if(!Array.isArray(src.periods)||!object(src.feedbacks||{})||!object(src.readings||{}))fail('INVALID_LEGACY');
   for(const p of src.periods){const key=p.start_date;apply(state,'period',key,valueFor('period',key,p));versions['period:'+key]=1;}
   for(const [key,v]of Object.entries(src.feedbacks||{})){apply(state,'feedback',key,valueFor('feedback',key,v));versions['feedback:'+key]=1;}
   for(const key of ['birth','cycleLength','manualChart','chartSource'])if(own(src,key)){state[key]=profile(key,src[key]);versions['profile:'+key]=1;}
   for(const [key,v]of Object.entries(src.readings||{})){if(!date(key)||!object(v)||JSON.stringify(v).length>30000)fail('INVALID_READING');state.readings[key]=v;}
   checkPeriods(state);
   const next={owner,state,versions,revision:1,lastOperations:[],legacyImported:true,updatedAt:db.serverDate()};if(saved)await docRef.update({data:{...next,state:db.command.set(state)}});else await docRef.set({data:next});return {...output({...doc,...next}),applied,conflicts,legacyImported:true};
  }
  const ops=event.operations;if(!Array.isArray(ops)||ops.length>100)fail('INVALID_OPERATIONS');
  for(const op of ops){
   if(!object(op)||typeof op.id!=='string'||!/^[A-Za-z0-9_-]{1,100}$/.test(op.id)||!['period','feedback','profile'].includes(op.kind)||typeof op.key!=='string'||!Number.isInteger(op.baseVersion)||op.baseVersion<0)fail('INVALID_OPERATION');
   const token=op.kind+':'+op.key;const v=valueFor(op.kind,op.key,op.value);
   const fingerprint=crypto.createHash('sha256').update(JSON.stringify([op.kind,op.key,v,op.baseVersion])).digest('hex');
   const previous=last.find(x=>x.id===op.id);
   if(previous){if(previous.fingerprint!==fingerprint)fail('OPERATION_ID_REUSED');applied.push(op.id);continue;}
   if((versions[token]||0)!==op.baseVersion){conflicts.push({id:op.id,kind:op.kind,key:op.key,version:versions[token]||0});continue;}
   apply(state,op.kind,op.key,v);versions[token]=(versions[token]||0)+1;applied.push(op.id);last.push({id:op.id,fingerprint});
  }
  checkPeriods(state);if(JSON.stringify(state).length>700000)fail('STATE_TOO_LARGE');
  const next={owner,state,versions,revision:doc.revision+(applied.some(opId=>!(doc.lastOperations||[]).some(x=>x.id===opId))?1:0),lastOperations:last.slice(-500),legacyImported:!!doc.legacyImported,updatedAt:db.serverDate()};
  const beforeHash=sourceHash(ownerSource(doc)),afterHash=sourceHash(ownerSource({...doc,state})),sourceChanged=beforeHash!==afterHash;
  if(sourceChanged)next.forecastInvalidated=afterHash;next.sourceHash=afterHash;next.sourceRevision=(doc.sourceRevision||0)+(sourceChanged?1:0);
  if(applied.length){if(saved)await docRef.update({data:{...next,state:db.command.set(state)}});else await docRef.set({data:next});}return {...output({...doc,...next}),applied,conflicts,_sourceChanged:sourceChanged,_created:!saved};
 });
 if(process.env.FORECAST_ENABLED!=='false'&&(action==='importLegacy'&&!response.skipped||response._sourceChanged||response._created)){const job=await forecast.ensure(db,id,{sourceChanged:!!response._sourceChanged});if(job)response.forecast=forecast.summary(job);}
 delete response._sourceChanged;delete response._created;
 return response;
};
