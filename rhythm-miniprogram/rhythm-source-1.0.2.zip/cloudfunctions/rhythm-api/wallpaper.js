'use strict';
const {Solar}=require('./vendor/lunar');
const TYPES=['yang-wood','yin-wood','yang-fire','yin-fire','yang-earth','yin-earth','yang-metal','yin-metal','yang-water','yin-water'];
const PREFIX='cloud://YOUR_CLOUDBASE_ENV_ID.7268-YOUR_CLOUDBASE_ENV_ID-1377108069/wallpaper-fallbacks/v5/';
function select(date,manifest){
 if(manifest&&typeof manifest.fileId==='string'&&manifest.fileId.startsWith('cloud://'))return {date,fileId:manifest.fileId,source:'generated'};
 const [y,m,d]=date.split('-').map(Number),stem=Solar.fromYmdHms(y,m,d,12,0,0).getLunar().getDayInGanZhi()[0],kind=TYPES['甲乙丙丁戊己庚辛壬癸'.indexOf(stem)];
 if(!kind)throw new Error('INVALID_WALLPAPER_DAY');
 return {date,fileId:PREFIX+kind+'.jpg',source:'v5-fallback',kind};
}
module.exports={select,TYPES};
