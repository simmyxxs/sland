const r = require('../../utils/rhythm');
const rhythmCopy = require('../../utils/rhythm-copy');
Page({
 onCloudUpdate(){this.setData({wallpaper:require('../../utils/cloud').wallpaperPath()});if(this.kind)this.refresh();},
 onLoad(q) {
  this.setData({wallpaper:require('../../utils/cloud').wallpaperPath()});
  if (q.kind === 'body' || q.kind === 'ganzhi') {
   wx.redirectTo({url:'/pages/settings/index?kind=' + (q.kind === 'body' ? 'period' : 'birth')});
   return;
  }
  this.kind = q.kind || 'basis';
  this.date = q.date || r.today();
  this.setData({kind:this.kind,rhythmCopy:rhythmCopy.moon});
  this.refresh();
 },
 onShow() { if (this.kind) this.refresh(); },
 refresh() {
  const title = this.kind === 'moon' ? '月亮' : '这一句的依据';
  this.setData({day:r.day(this.date),title});
  wx.setNavigationBarTitle({title});
 },
 copySource(e) { wx.setClipboardData({data:e.currentTarget.dataset.url}); }
});
