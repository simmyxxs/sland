const r=require('../../utils/rhythm');
Page({onCloudUpdate(){this.setData({wallpaper:require('../../utils/cloud').wallpaperPath()});},
 onLoad(q){this.setData({wallpaper:require('../../utils/cloud').wallpaperPath()});
  const date=q.date||r.today();
  if(date>r.today()){wx.navigateBack();return;}
  const feedback=r.load().feedbacks[date]||{};
  const score=feedback.prediction_accuracy;
  const rated=Number.isInteger(score)&&score>=0&&score<=10;
  this.setData({date,note:feedback.note||'',prediction_accuracy:rated?score:null,sliderValue:rated?score:0,rated,error:''});
 },
 accuracy(e){
  const score=Number(e.detail.value);
  this.setData({prediction_accuracy:score,sliderValue:score,rated:true,error:''});
 },
 chooseScore(e){this.accuracy({detail:{value:e.currentTarget.dataset.score}});},
 note(e){this.setData({note:e.detail.value});},
 save(){
  if(!this.data.rated)return this.setData({error:'请为预测准确度打分。'});
  const {date,prediction_accuracy,note}=this.data;
  try{
   const feedbacks=r.load().feedbacks;
   feedbacks[date]={...feedbacks[date],prediction_accuracy,note};
   r.save({feedbacks});
   wx.showToast({title:'感受已保存',icon:'none'});
   wx.navigateBack();
  }catch(e){this.setData({error:'请重新保存。'});}
 }
});
