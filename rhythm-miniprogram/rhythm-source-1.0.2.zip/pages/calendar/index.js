const r = require('../../utils/rhythm');
// Match the card surface's top breathing space, below its transparent edge.
const CARD_TOP_INSET_RPX = 12;

Page({
  onCloudUpdate(){this.setData({wallpaper:require('../../utils/cloud').wallpaperPath()});if(this.initialized)this.refreshCards();},
  data: {headerHeight:160, calendarCollapsed:false, weekOffset:0, tabVisible:false, week:['一','二','三','四','五','六','日'], upcoming:[], empty:false, showToday:false, scrollTop:0, animateScroll:false, tailHeight:0},
  onShow() {
    this.setData({wallpaper:require('../../utils/cloud').wallpaperPath()});
    clearTimeout(this.tabTimer);
    this.setData({tabVisible:false});
    this.tabTimer=setTimeout(()=>this.setData({tabVisible:true}),24);
    if(this.getTabBar())this.getTabBar().setData({selected:1});
    const info=wx.getWindowInfo?wx.getWindowInfo():wx.getSystemInfoSync();
    this.rpx=info.windowWidth/750;
    this.setData({topInset:(info.statusBarHeight||24)+14,cardShapeSize:Math.floor((info.windowWidth-128*this.rpx-1)*.42)});
    if(!this.initialized){
      this.initialized=true;
      this.month=r.today().slice(0,7);
      this.selected=r.today();
      this.loadCards();
      this.renderCalendar(()=>this.measure(()=>this.locate(this.selected,false)));
    }else{
      // Forms can update readings, but returning must retain the reading position.
      this.refreshCards();
    }
  },
  onHide(){clearTimeout(this.tabTimer);this.setData({tabVisible:false});},
  onUnload(){clearTimeout(this.tabTimer);clearTimeout(this.scrollTimer);clearTimeout(this.layoutTimer);this.cardGesture=null;},
  loadCards(){
    const readings=r.load().readings||{};
    const items=r.readingDates().filter(date=>{const v=readings[date];return v&&((v.headline||'').trim()||(v.suggestion||'').trim());}).map(date=>{const item=r.day(date);item.isToday=date===r.today();return item;});
    this.cardDates=items.map(item=>item.date);
    this.setData({upcoming:items,today:r.today()});
  },
  refreshCards(){
    this.loadCards();
    this.renderCalendar(()=>{
      // A selected day may acquire its first reading while this page is open
      // or behind a form. Reveal it without moving ordinary browsing sessions.
      if(this.data.empty&&this.cardDates.includes(this.selected))this.locate(this.selected,false);
      else this.measure();
    });
  },
  renderCalendar(done){
    const [y,m]=this.month.split('-').map(Number);
    const offset=(new Date(y,m-1,1).getDay()+6)%7;
    const count=new Date(y,m,0).getDate();
    const days=[];
    for(let i=0;i<42;i++){
      const n=i-offset+1;
      if((n<1||n>count)&&!this.data.calendarCollapsed){days.push({key:'blank'+i,blank:true});continue;}
      const cell=new Date(y,m-1,n);
      const date=cell.getFullYear()+'-'+String(cell.getMonth()+1).padStart(2,'0')+'-'+String(cell.getDate()).padStart(2,'0'),d=r.day(date);
      days.push({key:date,date,n:cell.getDate(),selected:date===this.selected,today:date===r.today(),recorded:d.body.phase==='menstrual'&&d.body.quality==='recorded',predicted:d.body.phase==='menstrual'&&d.body.quality==='estimated'});
    }
    const selectedDay=Number(this.selected.slice(-2));
    const weekOffset=Math.floor((offset+selectedDay-1)/7)*76;
    this.setData({year:y,month:m,days,weekOffset,showToday:this.data.empty||this.selected!==r.today()||this.visibleDate!==r.today()},done);
  },
  measure(done){
    wx.nextTick(()=>wx.createSelectorQuery().in(this).select('.calendar-header-fixed').boundingClientRect(rect=>{
      const finish=()=>wx.nextTick(()=>wx.createSelectorQuery().in(this).select('.calendar-scroll').boundingClientRect().selectAll('.day-card').boundingClientRect().select('.day-art').boundingClientRect().exec(result=>{
        const viewport=result[0],cards=result[1]||[],art=result[2];
        // The canvas must stay square inside the real card column. Its 400-unit
        // drawing already includes the complete outer contours and breathing room.
        if(art&&art.width>0&&this.data.cardShapeSize!==Math.floor(art.width)){
          this.setData({cardShapeSize:Math.floor(art.width)});
        }
        if(viewport&&cards.length){
          this.cardOffsets=cards.map((card,index)=>({date:this.cardDates[index],top:card.top-viewport.top+(this.scrollPosition||0)}));
          this.setData({tailHeight:Math.max(0,viewport.height-cards[cards.length-1].height-CARD_TOP_INSET_RPX*this.rpx-14)});
        }
        if(done)done();
      }));
      if(!this.layoutChanging&&rect&&this.data.headerHeight!==Math.ceil(rect.height))this.setData({headerHeight:Math.ceil(rect.height)},finish);else finish();
    }).exec());
  },
  locate(date,animate=true){
    clearTimeout(this.scrollTimer);
    this.userScrolling=false;
    this.programTarget=null;
    if(!(this.cardDates||[]).includes(date)){
      this.visibleDate=null;
      this.setData({empty:true,emptyText:date.slice(5).replace('-',' 月 ')+' 日暂无解读',showToday:true});
      return;
    }
    const move=()=>this.measure(()=>{
      const target=(this.cardOffsets||[]).find(item=>item.date===date);
      if(!target)return;
      this.programTarget=date;
      this.visibleDate=date;
      const actual=Math.max(0,this.scrollPosition||0),destination=Math.max(0,target.top-CARD_TOP_INSET_RPX*this.rpx);
      // Rebase the bound value after native/manual scrolling. Otherwise returning
      // to the previous programmatic destination may be ignored as an unchanged prop.
      this.setData({animateScroll:false,scrollTop:actual},()=>wx.nextTick(()=>{
        this.setData({animateScroll:animate,scrollTop:destination,showToday:date!==r.today()});
        if(Math.abs(actual-destination)<2)this.programTarget=null;
      }));
    });
    if(this.data.empty)this.setData({empty:false},move);else move();
  },
  setCalendarCollapsed(collapsed){
    if(this.data.calendarCollapsed===collapsed)return;
    clearTimeout(this.layoutTimer);
    // Keep the content coordinate unchanged as only its viewport grows/shrinks.
    // Do not sample an intermediate animated header height during locate().
    this.layoutChanging=true;
    this.resetCalendarTravel();
    this.gestureCooldownUntil=Date.now()+790;
    if(this.cardGesture)this.cardGesture.handled=true;
    const delta=380*this.rpx*(collapsed?-1:1);
    this.setData({calendarCollapsed:collapsed,headerHeight:this.data.headerHeight+delta,tailHeight:Math.max(0,this.data.tailHeight-delta)});
    this.renderCalendar();
    this.layoutTimer=setTimeout(()=>{
      this.layoutChanging=false;
      this.measure();
    },340);
  },
  toggleCalendar(){
    this.userScrolling=false;
    this.setCalendarCollapsed(!this.data.calendarCollapsed);
  },
  onScroll(e){
    const previous=this.scrollPosition||0;
    this.scrollPosition=e.detail.scrollTop;
    // Scroll deltas cover desktop wheels too. Layout/programmatic motion must
    // never be mistaken for a gesture in either direction.
    if(!this.programTarget&&!this.layoutChanging&&Date.now()>(this.gestureCooldownUntil||0)){
      this.trackCalendarTravel(this.scrollPosition-previous);
    }
    clearTimeout(this.scrollTimer);
    if(!this.programTarget)this.syncReading();
    this.scrollTimer=setTimeout(()=>{
      this.programTarget=null;
      this.syncReading();
    },180);
  },
  resetCalendarTravel(){this.calendarTravel=0;this.calendarDirection=0;},
  trackCalendarTravel(delta){
    if(Math.abs(delta)<1)return;
    const now=Date.now(),direction=delta>0?1:-1;
    if(now-(this.lastTravelAt||0)>240||direction!==this.calendarDirection)this.calendarTravel=0;
    this.lastTravelAt=now;
    this.calendarDirection=direction;
    this.calendarTravel+=Math.abs(delta);
    if((!this.data.calendarCollapsed&&direction>0&&this.calendarTravel>=40)||
       (this.data.calendarCollapsed&&direction<0&&this.calendarTravel>=56)){
      this.setCalendarCollapsed(!this.data.calendarCollapsed);
    }
  },
  takeScrollControl(e){
    clearTimeout(this.scrollTimer);this.programTarget=null;this.userScrolling=true;this.resetCalendarTravel();
    const p=e.touches&&e.touches[0];
    this.cardGesture=p?{x:p.clientX,y:p.clientY,handled:false}:null;
  },
  cardTouchMove(e){
    const gesture=this.cardGesture,p=e.touches&&e.touches[0];
    if(!gesture||!p||gesture.handled||this.layoutChanging||Date.now()<(this.gestureCooldownUntil||0))return;
    const dy=p.clientY-gesture.y,dx=p.clientX-gesture.x;
    // Native scroll cannot report a pull at the beginning of the list.
    if(this.data.calendarCollapsed&&dy>=56&&dy>Math.abs(dx)*1.4){
      gesture.handled=true;this.setCalendarCollapsed(false);
    }
  },
  cardTouchEnd(){this.cardGesture=null;},
  syncReading(){
    if(this.data.empty||!this.cardOffsets||!this.cardOffsets.length)return;
    const position=(this.scrollPosition||0)+CARD_TOP_INSET_RPX*this.rpx+12;
    let current=this.cardOffsets[0];
    for(const card of this.cardOffsets){if(card.top>position)break;current=card;}
    if(this.visibleDate===current.date&&this.selected===current.date)return;
    this.visibleDate=current.date;
    this.selected=current.date;
    this.month=current.date.slice(0,7);
    this.renderCalendar();
  },
  select(e){
    if(Date.now()<(this.suppressDateTapUntil||0))return;
    this.selected=e.currentTarget.dataset.date;
    this.month=this.selected.slice(0,7);
    this.userScrolling=false;
    this.setCalendarCollapsed(true);
    this.renderCalendar(()=>this.locate(this.selected));
  },
  change(e){this.shiftMonth(Number(e.currentTarget.dataset.delta));},
  shiftMonth(delta){
    const [y,m]=this.month.split('-').map(Number),d=new Date(y,m-1+delta,1);
    this.month=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
    const dates=(this.cardDates||[]).filter(date=>date.slice(0,7)===this.month);
    this.selected=this.month===r.today().slice(0,7)&&dates.includes(r.today())?r.today():(dates[0]||this.month+'-01');
    this.renderCalendar(()=>this.locate(this.selected));
  },
  monthTouchStart(e){const p=e.touches[0];this.monthGesture={x:p.clientX,y:p.clientY};},
  monthTouchEnd(e){
    if(!this.monthGesture||!e.changedTouches.length)return;
    const p=e.changedTouches[0],dx=p.clientX-this.monthGesture.x,dy=p.clientY-this.monthGesture.y;
    this.monthGesture=null;
    if(Math.abs(dy)>56&&Math.abs(dy)>Math.abs(dx)*1.5){
      this.suppressDateTapUntil=Date.now()+350;
      this.setCalendarCollapsed(dy<0);
    }else if(Math.abs(dx)>48&&Math.abs(dx)>Math.abs(dy)*1.5){
      this.suppressDateTapUntil=Date.now()+350;
      this.shiftMonth(dx<0?1:-1);
    }
  },
  goToday(){this.setCalendarCollapsed(false);this.selected=r.today();this.month=this.selected.slice(0,7);this.renderCalendar(()=>this.locate(this.selected));},
  feedback(e){wx.navigateTo({url:'/pages/feedback/index?date='+e.currentTarget.dataset.date});}
});
