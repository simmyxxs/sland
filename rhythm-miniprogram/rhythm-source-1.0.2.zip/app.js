App({
  globalData: {cloudInitialized: false},
  onShow() {
    if (this.globalData.cloudInitialized) require('./utils/cloud').start();
  },
  onHide() {
    if (this.globalData.cloudInitialized) require('./utils/cloud').stop();
  },
  onLaunch() {
    if (!wx.cloud || typeof wx.cloud.init !== 'function') return;
    try {
      wx.cloud.init({
        env: 'YOUR_CLOUDBASE_ENV_ID',
        traceUser: false
      });
      this.globalData.cloudInitialized = true;
      require('./utils/cloud').start();
    } catch (error) {
      // Cloud availability must not prevent the existing local app from opening.
      this.globalData.cloudInitialized = false;
    }
  }
});
