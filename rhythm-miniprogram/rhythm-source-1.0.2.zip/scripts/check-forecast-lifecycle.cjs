const fs=require('fs'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const root=process.cwd()+'/cloudfunctions/',planner=require(root+'rhythm-api/forecast'),source=require(root+'rhythm-api/source');
const docs=new Map(),clone=x=>JSON.parse(JSON.stringify(x));
const db={command:{},serverDate:()=>Date.now(),collection(c){return {doc(id){const key=c+'/'+id;return {get:async()=>{if(!docs.has(key))throw Object.assign(Error('not found'),{errCode:-502001});return {data:clone(docs.get(key))}},set:async({data})=>docs.set(key,clone(data)),update:async({data})=>{const v=docs.get(key);for(const[k,val]of Object.entries(data)){if(k==='state.readings')v.state.readings=clone(val);else v[k]=clone(val)}}}}}},runTransaction:fn=>fn(db)};
const put=(id,v)=>docs.set('user_state/'+id,clone(v)),read=id=>docs.get('user_state/'+id),job=id=>docs.get('forecast_jobs/'+id),window=planner.datesFor('2026-10-22');
const original={periods:[],feedbacks:{},birth:{},manualChart:{},chartSource:'date',cycleLength:28,readings:Object.fromEntries(window.map(d=>[d,{headline:'旧文保留，风格如初'}]))};
(async()=>{
put('a',{state:original,revision:2,readingMeta:{}});assert.equal(await planner.ensure(db,'a',{today:'2026-10-22'}),null);
let j=await planner.ensure(db,'a',{today:'2026-10-23'});assert.deepEqual(j.dates,['2026-11-22']);assert.equal(j.promptVersion,'rhythm-copy-v2-four-by-four');let again=await planner.ensure(db,'a',{today:'2026-10-24'});assert.equal(again.generationId,j.generationId);assert.equal(again.offset,0);
read('a').state.cycleLength=30;let changed=await planner.ensure(db,'a',{today:'2026-10-22',sourceChanged:true});assert(changed.dates.every(d=>d>'2026-10-22'));assert.notEqual(changed.generationId,j.generationId);assert(changed.replaceFuture);
put('b',{state:original,revision:7,personalFacts:{context:{value:'owner-b-only',date:'2026-10-22'}},readingMeta:{}});assert.notEqual(source.sourceHash(source.ownerSource(read('a'))),source.sourceHash(source.ownerSource(read('b'))));
assert.equal(source.sourceHash({...original,readings:{},revision:100,today:'2099-01-01'}),source.sourceHash(original));
// Exercise worker publish without any model, SDK network, or real database.
let exports={};const sandbox={exports,Buffer,URL,Date,process:{env:{}},AbortController,setTimeout,clearTimeout,require(n){if(n==='wx-server-sdk')return {init(){},getWXContext:()=>({}),database:()=>db};if(n==='crypto')return crypto;if(n==='./inputs')return {...require(root+'rhythm-forecast/inputs'),today:()=> '2026-10-22'};if(n.startsWith('./'))return require(root+'rhythm-forecast/'+n.slice(2));throw Error(n)}};
vm.runInNewContext(fs.readFileSync(root+'rhythm-forecast/index.js','utf8')+'\nexports.test={publish,claim};',sandbox);
const inspected=await exports.main({internal:true,action:'inspect'});assert.equal(inspected.status,'ready');assert.equal(inspected.contractVersion,2);
let task=job('a');task.leaseToken='lease';task.status='running';task.outputs=Object.fromEntries(task.dates.map(d=>[d,{headline:'新文四字，方向如初'}]));task.offset=task.dates.length;
const todayOriginal=read('a').state.readings['2026-10-22'];assert.equal(await exports.test.publish('a',clone(task)),true);assert.deepEqual(read('a').state.readings['2026-10-22'],todayOriginal);assert.equal(read('a').revision,3);assert.equal(read('b').revision,7);const saved=JSON.stringify(read('a'));await exports.test.publish('a',clone(task));assert.equal(JSON.stringify(read('a')),saved);assert(docs.has('forecast_jobs/result-a-'+task.generationId));
// Stale task cannot publish after source changes.
read('a').state.cycleLength=31;const stale=await planner.ensure(db,'a',{today:'2026-10-22',sourceChanged:true});job('a').leaseToken='next';stale.leaseToken='next';read('a').state.cycleLength=32;assert.equal(await exports.test.publish('a',stale),false);
assert.equal(planner.datesFor('2027-01-31').at(-1),'2027-02-27');assert.equal(planner.datesFor('2028-01-31').at(-1),'2028-02-28');
const historic=await planner.ensure(db,'b',{today:'2026-10-22'});assert.equal(historic,null);
console.log('PASS stable-source, cross-day one-tail-day, active progress retained, source-change future-only, owner isolation, publish revision/archive/idempotence/stale rejection, month-end horizons. No network/model.');
})().catch(e=>{console.error(e);process.exitCode=1});
