// Personal preview records are excluded from the distributable application.
module.exports={importedAt:null,periods:[],feedbacks:{},readings:{}};
