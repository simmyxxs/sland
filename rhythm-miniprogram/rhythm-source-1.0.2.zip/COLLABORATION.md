# 节律 · 1.0.2 公开协作源码

这是原生微信小程序的确认版本 1.0.2 协作副本，产品代码基线为 `65052b0`。公开副本将应用与云环境标识改成占位符，并替换内部运行记录文档；不包含原私人 Git 历史，不是已连接云环境的开箱即用发行包。

## 获取与导入

```sh
git clone https://github.com/simmyxxs/sland.git
cd sland/rhythm-miniprogram
```

使用微信开发者工具导入此子目录。先按 CONFIGURATION.md 配置自己的开发 AppID 和云环境；微信后台开发者身份、云环境权限与 GitHub 写入权限分别授予。根目录没有 npm 构建依赖，各云函数依赖在各自 package.json 中。

## 协作

任何人都可以克隆、fork 并提交 Pull Request；直接推送需仓库维护者授予权限。在自己的分支修改，确认后合并。不要把用户数据、密钥、私有配置或运行日志提交到公开仓库。只在独立开发环境联调，生产部署由维护者安排。

源码入口为 pages、components、utils、cloudfunctions。聚合动画与底部胶囊属于已确认设计，修改前与维护者对齐。

摄影署名及许可见 assets/wallpapers-v5/credits.json，第三方库许可见对应 LICENSE；未附来源证明的试验素材不要单独再分发。个人资料不在此源码中。云函数配置以当前代码和独立开发环境为准。
