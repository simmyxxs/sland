const {color}=require('./shape-style');
  const mix = (a, b, t) => a + (b - a) * t;
  // Approved silhouette family: rounded curved ribbon → soft bean → organic disc.
  // All outlines use six cubic sections, sampled by perimeter before interpolation.
  function bezierOutline(segments) {
    const points=[];
    segments.forEach(([a,b,c,d])=>{
      for(let i=0;i<24;i++){
        const t=i/24,u=1-t;
        points.push([0,1].map(axis=>u*u*u*a[axis]+3*u*u*t*b[axis]+3*u*t*t*c[axis]+t*t*t*d[axis]));
      }
    });
    return points;
  }
  const ribbon=bezierOutline([
    [[275,91],[287,88],[294,101],[285,111]],
    [[285,111],[252,138],[255,174],[227,210]],
    [[227,210],[202,247],[156,279],[123,291]],
    [[123,291],[100,298],[96,275],[116,268]],
    [[116,268],[161,255],[195,238],[212,204]],
    [[212,204],[236,163],[238,107],[275,91]]
  ]);
  const bean=bezierOutline([
    [[248,92],[283,88],[290,112],[267,136]],
    [[267,136],[227,176],[224,220],[264,248]],
    [[264,248],[300,271],[267,305],[229,308]],
    [[229,308],[163,317],[106,283],[91,232]],
    [[91,232],[72,177],[116,126],[164,107]],
    [[164,107],[193,95],[223,90],[248,92]]
  ]);
  const disc=bezierOutline([
    [[251,102],[289,120],[313,151],[312,193]],
    [[312,193],[318,235],[286,278],[250,297]],
    [[250,297],[214,315],[169,310],[138,292]],
    [[138,292],[99,270],[86,234],[89,195]],
    [[89,195],[88,154],[113,119],[149,102]],
    [[149,102],[185,80],[219,87],[251,102]]
  ]);
  function geometry(phase,time) {
    const fullness=(1-Math.cos(phase*Math.PI*2))/2;
    let from,to,amount;
    if(fullness<.55){from=ribbon;to=bean;amount=Math.pow(fullness/.55,2.6);}
    else{from=bean;to=disc;amount=(fullness-.55)/.45;}
    amount=amount*amount*(3-2*amount);
    const waning=Math.sin(phase*Math.PI*2)<0;
    return from.map((p,i)=>{
      let x=mix(p[0],to[i][0],amount)-200,y=mix(p[1],to[i][1],amount)-200;
      // Slow whole-form breathing preserves the approved outline; no scalloped waves.
      const breathe=1+.006*Math.sin(time*.48);
      if(waning)x=-x;
      const lean=.035*Math.sin(phase*Math.PI*2);
      return [200+(x+y*lean)*breathe,200+y*breathe];
    });
  }

module.exports={geometry,color};
