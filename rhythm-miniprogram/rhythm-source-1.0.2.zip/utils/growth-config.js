// Final preview selection approved 2026-10-22.
module.exports={effect:'growth',motion:true,dots:false,duration:2600};
