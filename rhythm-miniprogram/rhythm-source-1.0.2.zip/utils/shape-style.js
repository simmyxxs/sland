// Shared visual tokens. Strength blends the whole silhouette, never its area.
const palettes={wood:['#7DD486','#43B95C'],fire:['#F03939','#ED1717'],earth:['#F8E36A','#F3D21A'],metal:['#C8C8C8','#ACACAC'],water:['#91CDD9','#329CB7']};
const neutral={strength:.5,opacity:.68};
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
function cycleStyle(day,cycleLength,bleedingDays){
 if(!Number.isFinite(day)||!Number.isFinite(cycleLength)||cycleLength<=0)return {...neutral};
 const length=cycleLength,bleed=clamp(bleedingDays||5,1,length*.35);
 const peak=clamp(length-14,bleed+1,length*.72);
 const nodes=[[0,.15,.52],[(bleed+peak)/2,.55,.68],[peak,1,.84],[(peak+length)/2,.4,.62],[length,.15,.52]];
 const position=((day%length)+length)%length;
 for(let i=1;i<nodes.length;i++){const a=nodes[i-1],b=nodes[i];if(position<=b[0]){const t=(position-a[0])/(b[0]-a[0]),ease=(1-Math.cos(Math.PI*t))/2;return {strength:a[1]+(b[1]-a[1])*ease,opacity:a[2]+(b[2]-a[2])*ease};}}
 return {...neutral};
}
function color(element,strength){const pair=palettes[element]||palettes.water,t=Number.isFinite(strength)?clamp(strength,0,1):neutral.strength;return [1,3,5].map(i=>{const a=parseInt(pair[0].slice(i,i+2),16),b=parseInt(pair[1].slice(i,i+2),16);return a+(b-a)*t;});}
// Moon sets the final optical weight; smooth, closed new-moon → full-moon → new-moon.
function moonStyle(phase){if(!Number.isFinite(phase))return {strength:1,opacity:neutral.opacity};const fullness=(1-Math.cos(phase*Math.PI*2))/2;return {strength:1,opacity:.52+.32*fullness};}
// Map a complete body cycle onto the approved 22-second source path.
function bodyTime(day,length,bleedingDays){
 if(!Number.isFinite(day)||!Number.isFinite(length)||length<=0)return 7.5;
 // Keep the visual peak at the same 14-days-before-next-period anchor as body().
 const bleed=clamp(bleedingDays||5,1,length*.35),peak=clamp(length-14,bleed+1,length-1);
 const start=Math.max(bleed,peak-2),end=Math.min(length-1,peak+2),position=((day%length)+length)%length;
 if(position<start)return position/start*15;
 if(position<=end)return 15+(position-start)/(end-start)*2;
 return 17+(position-end)/(length-end)*5;
}
module.exports={palettes,neutral,cycleStyle,moonStyle,bodyTime,color};
