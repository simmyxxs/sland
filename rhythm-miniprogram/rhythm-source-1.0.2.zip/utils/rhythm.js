const {Solar}=require('../vendor/lunar');
const cloud=require('./cloud');
const {moonStyle,bodyTime}=require('./shape-style');
const pad=n=>String(n).padStart(2,'0');
const iso=d=>`${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())}`;
const today=()=>iso(new Date(Date.now()+8*3600000));
const stamp=s=>Date.parse(s+'T12:00:00+08:00');
const add=(s,n)=>iso(new Date(stamp(s)+n*86400000));
function load(){return cloud.load();}
function save(patch){return cloud.save(patch);}
function readingDates(){return Object.keys(load().readings||{}).sort();}
function moon(date){
 const days=stamp(date)/86400000+2440587.5-2451545,rad=Math.PI/180,e=rad*23.4397;
 const coords=(l,b)=>[Math.atan2(Math.sin(l)*Math.cos(e)-Math.tan(b)*Math.sin(e),Math.cos(l)),Math.asin(Math.sin(b)*Math.cos(e)+Math.cos(b)*Math.sin(e)*Math.sin(l))];
 const M=rad*(357.5291+.98560028*days),L=M+rad*(1.9148*Math.sin(M)+.02*Math.sin(2*M)+.0003*Math.sin(3*M))+rad*102.9372+Math.PI;
 const [sra,sdec]=coords(L,0),lm=rad*(218.316+13.176396*days),mm=rad*(134.963+13.064993*days),f=rad*(93.272+13.229350*days);
 const [mra,mdec]=coords(lm+rad*6.289*Math.sin(mm),rad*5.128*Math.sin(f)),dist=385001-20905*Math.cos(mm);
 const phi=Math.acos(Math.max(-1,Math.min(1,Math.sin(sdec)*Math.sin(mdec)+Math.cos(sdec)*Math.cos(mdec)*Math.cos(sra-mra))));
 const inc=Math.atan2(149598000*Math.sin(phi),dist-149598000*Math.cos(phi)),angle=Math.atan2(Math.cos(sdec)*Math.sin(sra-mra),Math.sin(sdec)*Math.cos(mdec)-Math.cos(sdec)*Math.sin(mdec)*Math.cos(sra-mra));
 const phase=(.5+.5*inc*(angle<0?-1:1)/Math.PI+1)%1;
 return {phase_fraction:phase,phase_name:['新月','蛾眉月','上弦月','盈凸月','满月','亏凸月','下弦月','残月'][Math.floor(phase*8+.5)%8],illumination:Math.round((1+Math.cos(inc))*50)};
}
function body(date){
 const rows=load().periods.filter(r=>r.start_date<=date).sort((a,b)=>b.start_date.localeCompare(a.start_date));
 const base={phase:'unknown',label:'阶段待确认',quality:'unknown',explanation:'记录月经日期，观察身体节律。'};
 if(!rows.length)return base;
 const latest=rows[0],active=(!latest.end_date?date<=today():date<=latest.end_date);
 const durations=rows.filter(r=>r.end_date&&r.end_date<=date).map(r=>Math.round((stamp(r.end_date)-stamp(r.start_date))/86400000)+1);
 const gaps=rows.slice(1).map((r,i)=>Math.round((stamp(rows[i].start_date)-stamp(r.start_date))/86400000));
 const avg=gaps.length?Math.round(gaps.reduce((a,b)=>a+b,0)/gaps.length):Number(load().cycleLength)||0;
 if(active)return Object.assign(base,{phase:'menstrual',label:'月经期',quality:'recorded',explanation:`实际记录：${latest.start_date} — ${latest.end_date||'进行中'}。`});
 if(!avg)return Object.assign(base,{explanation:'记录下一次月经，逐步看见周期。'});
 let expected=add(latest.start_date,avg),n=Math.round((stamp(date)-stamp(latest.start_date))/86400000)+1;
 if(date>=expected&&date<=today())return Object.assign(base,{label:'阶段待更新',explanation:'经期已到，记录这次月经可更新身体阶段。'});
 let phase;
 if(date>=expected){let projected=expected;while(add(projected,avg)<=date)projected=add(projected,avg);n=Math.round((stamp(date)-stamp(projected))/86400000)+1;expected=add(projected,avg);const bleeding=durations.length?Math.round(durations.reduce((a,b)=>a+b,0)/durations.length):3;phase=n<=bleeding?'menstrual':date<add(expected,-16)?'follicular':date<=add(expected,-12)?'ovulatory':'luteal';}
 else phase=date<add(expected,-16)?'follicular':date<=add(expected,-12)?'ovulatory':'luteal';
 return {phase,label:{menstrual:'月经期',follicular:'卵泡期',ovulatory:'排卵期',luteal:'黄体期'}[phase],quality:'estimated',explanation:`${gaps.length?'记录的平均':'参考'}周期 ${avg} 天，下次月经 ${expected}。`};
}
function bodyAppearance(date,state){
 if(state.phase==='unknown')return {time:7.5,known:false};
 const data=load(),rows=data.periods.filter(r=>r.start_date<=date).sort((a,b)=>b.start_date.localeCompare(a.start_date));
 if(!rows.length)return {time:7.5,known:false};
 const gaps=rows.slice(1).map((r,i)=>(stamp(rows[i].start_date)-stamp(r.start_date))/86400000).filter(n=>n>0);
 const length=gaps.length?gaps.reduce((a,b)=>a+b,0)/gaps.length:Number(data.cycleLength);
 if(!Number.isFinite(length)||length<=0)return {time:7.5,known:false};
 const durations=rows.filter(r=>r.end_date&&r.end_date<=date).map(r=>(stamp(r.end_date)-stamp(r.start_date))/86400000+1);
 const bleeding=durations.length?durations.reduce((a,b)=>a+b,0)/durations.length:5;
 return {time:bodyTime((stamp(date)-stamp(rows[0].start_date))/86400000,length,bleeding),known:true};
}
function day(date){const moonState=moon(date);Object.assign(moonState,moonStyle(moonState.phase_fraction));const bodyState=body(date);Object.assign(bodyState,bodyAppearance(date,bodyState));const [y,m,d]=date.split('-').map(Number),l=Solar.fromYmdHms(y,m,d,12,0,0).getLunar(),g=l.getDayInGanZhi(),ix='甲乙丙丁戊己庚辛壬癸'.indexOf(g[0])>>1;
 const reading=(load().readings||{})[date]||null;return {reading,prettyDate:m+'月'+d+'日',weekday:['星期日','星期一','星期二','星期三','星期四','星期五','星期六'][new Date(stamp(date)).getDay()],date,shortDate:date.slice(5).replace('-','.'),displayDate:date.replace(/-/g,'.'),lunar:l.getMonthInChinese()+'月'+l.getDayInChinese(),term:l.getPrevJieQi().getName(),moon:moonState,body:bodyState,ganzhi:{day:g,year:l.getYearInGanZhiByLiChun(),month:l.getMonthInGanZhi(),element:['wood','fire','earth','metal','water'][ix],element_name:['木','火','土','金','水'][ix]},headline:reading&&reading.headline||(date===today()?'今天的节律。':'这一天的节律。'),feedback:load().feedbacks[date]||null,future:date>today()};}
function manualChartError(chart){
 const names=['年柱','月柱','日柱','时柱'], keys=['year','month','day','time'];
 for(let i=0;i<keys.length;i++){const value=(chart[keys[i]]||'').trim();if(i===3&&chart.unknown)continue;const gan='甲乙丙丁戊己庚辛壬癸'.indexOf(value[0]),zhi='子丑寅卯辰巳午未申酉戌亥'.indexOf(value[1]);if(value.length!==2||gan<0||zhi<0||gan%2!==zhi%2)return names[i]+'请填写有效的两字干支。';}return '';
}
function hasBirth(data){return !!(data.birth&&data.birth.date)||!!(data.manualChart&&!manualChartError(data.manualChart));}
function activeBirthChart(data){if(data.chartSource==='manual'&&data.manualChart&&!manualChartError(data.manualChart)){const c=data.manualChart;return [c.year,c.month,c.day,c.unknown?'时辰未定':c.time].join(' · ');}return birthChart(data.birth||{});}
function birthChart(b){if(!b.date)return '';const [y,m,d]=b.date.split('-').map(Number),[h,min]=(b.unknown?'12:00':b.time||'12:00').split(':').map(Number);const ec=Solar.fromYmdHms(y,m,d,h,min,0).getLunar().getEightChar();return `${ec.getYear()} · ${ec.getMonth()} · ${ec.getDay()}${b.unknown?' · 时辰未定':' · '+ec.getTime()}`;}
module.exports={readingDates,today,add,load,save,day,birthChart,manualChartError,hasBirth,activeBirthChart};
