const LEGACY_KEY='rhythm-native-v1';
const ACTIVE_KEY='rhythm-cloud-active-v1';
const LEGACY_OWNER_KEY='rhythm-legacy-owner-v1';
const FALLBACK='/assets/misty-sand-trial.jpg';
const CONSENT_VERSION='rhythm-cloud-purpose-v1';
let consentRequest=null,consentOnSave=false;
let identity='',sessionReady=false,busy=false,retryTimer=null,forecastTimer=null,visible=true;
const empty=()=>({periods:[],feedbacks:{},birth:{},manualChart:{},chartSource:'date',cycleLength:null,readings:{}});
const clone=v=>JSON.parse(JSON.stringify(v));
const key=()=>identity?'rhythm-cloud-user-v1:'+identity:'rhythm-cloud-guest-v1';
function read(){return wx.getStorageSync(key())||{state:empty(),versions:{},pending:[]};}
function write(v){wx.setStorageSync(key(),v);}
function legacy(){const v=wx.getStorageSync(LEGACY_KEY);return v&&typeof v==='object'?v:null;}
function localLegacy(){const old=legacy();if(!old)return null;const owner=wx.getStorageSync(LEGACY_OWNER_KEY);if(identity){if(owner!==identity)return null;}else{if(sessionReady)return null;try{if(wx.getAccountInfoSync().miniProgram.envVersion!=='develop')return null;}catch(e){return null;}}return !read().legacyImported?old:null;}
function load(){const old=localLegacy();if(old)return Object.assign(empty(),clone(old));return Object.assign(empty(),clone(read().state||{}));}
function recordKey(op){return op.kind+':'+op.key;}
function apply(state,op){if(op.kind==='profile')state[op.key]=op.value;else if(op.kind==='period'){state.periods=state.periods.filter(p=>p.start_date!==op.key);if(op.value)state.periods.push(op.value);state.periods.sort((a,b)=>b.start_date.localeCompare(a.start_date));}else if(op.kind==='feedback'){if(op.value)state.feedbacks[op.key]=op.value;else delete state.feedbacks[op.key];}}
function save(patch){
 consentOnSave=true;
 if(localLegacy()){const v=Object.assign(load(),patch);wx.setStorageSync(LEGACY_KEY,v);if(sessionReady)migrateLegacy(true).catch(()=>{}).finally(()=>{consentOnSave=false;});return v;}
 const cache=read(),before=Object.assign(empty(),cache.state),ops=[];
 const add=(kind,k,value)=>{const previous=(cache.pending||[]).filter(o=>o.kind===kind&&o.key===k).pop();ops.push({id:Date.now().toString(36)+'-'+Math.random().toString(36).slice(2),kind,key:k,value:clone(value),baseVersion:previous?previous.baseVersion:(cache.versions||{})[kind+':'+k]||0});};
 Object.keys(patch).forEach(k=>{
  if(k==='periods'){const old=Object.fromEntries(before.periods.map(p=>[p.start_date,p])),next=Object.fromEntries(patch.periods.map(p=>[p.start_date,p]));new Set([...Object.keys(old),...Object.keys(next)]).forEach(d=>{if(JSON.stringify(old[d])!==JSON.stringify(next[d]))add('period',d,next[d]||null);});}
  else if(k==='feedbacks'){new Set([...Object.keys(before.feedbacks),...Object.keys(patch.feedbacks)]).forEach(d=>{if(JSON.stringify(before.feedbacks[d])!==JSON.stringify(patch.feedbacks[d]))add('feedback',d,patch.feedbacks[d]||null);});}
  else if(['birth','cycleLength','manualChart','chartSource'].includes(k)&&JSON.stringify(before[k])!==JSON.stringify(patch[k]))add('profile',k,patch[k]);
 });
 cache.state=Object.assign(before,clone(patch));cache.pending=cache.pending||[];
 ops.forEach(op=>{cache.pending=cache.pending.filter(p=>recordKey(p)!==recordKey(op));cache.conflicts=(cache.conflicts||[]).filter(c=>!c.operation||recordKey(c.operation)!==recordKey(op));cache.pending.push(op);});write(cache);flush(true);return clone(cache.state);
}
function hasConsent(owner){return !!owner&&wx.getStorageSync('rhythm-cloud-consent-v1:'+owner)===CONSENT_VERSION;}
function ensureConsent(owner,allowPrompt){
 if(!owner||owner!==identity)return Promise.reject(new Error('CONSENT_IDENTITY_CHANGED'));
 if(hasConsent(owner))return Promise.resolve();
 if(!allowPrompt)return Promise.reject(new Error('CONSENT_REQUIRED'));
 if(consentRequest&&consentRequest.owner===owner)return consentRequest.promise;
 const promise=new Promise((resolve,reject)=>wx.showModal({title:'个人资料的使用',content:'为同步你的个人节律，经期、出生资料和感受将保存在腾讯云，相关事实会发送给 DeepSeek 生成你的解读。是否同意？',confirmText:'同意并同步',cancelText:'暂不同意',success(result){if(!result.confirm)return reject(new Error('CONSENT_DECLINED'));if(owner!==identity)return reject(new Error('CONSENT_IDENTITY_CHANGED'));wx.setStorageSync('rhythm-cloud-consent-v1:'+owner,CONSENT_VERSION);resolve();},fail(){reject(new Error('CONSENT_UNAVAILABLE'));}})).finally(()=>{if(consentRequest&&consentRequest.owner===owner)consentRequest=null;});
 consentRequest={owner,promise};return promise;
}
async function call(data,allowPrompt=false){
 const owner=identity;if(data.action==='mutate'||data.action==='importLegacy'){await ensureConsent(owner,allowPrompt);if(identity!==owner)throw new Error('CONSENT_IDENTITY_CHANGED');}
 const r=await wx.cloud.callFunction({name:'rhythm-api',data});if(!r.result||r.result.error)throw new Error(r.result&&r.result.error||'Cloud response unavailable');return r.result;
}
async function migrateLegacy(allowPrompt=false){
 const old=localLegacy();if(!old||!sessionReady)return;
 const owner=identity;const result=await call({action:'importLegacy',state:old},allowPrompt);if(identity!==owner)return;
 const cache=read();overlay(cache,result);cache.legacyImported=!!result.legacyImported;write(cache);notify();
 const newer=legacy();if(cache.legacyImported&&newer&&JSON.stringify(newer)!==JSON.stringify(old))save(newer);
}

function notify(){const pages=typeof getCurrentPages==='function'?getCurrentPages():[];pages.forEach(p=>{if(typeof p.onCloudUpdate==='function')p.onCloudUpdate();});}
function retry(){clearTimeout(retryTimer);retryTimer=setTimeout(()=>{retryTimer=null;if(sessionReady)flush();else start();},30000);}
function triggerForecast(info){
 if(!visible||!sessionReady||!identity||!info||info.status!=='queued'||!info.generationId)return;
 const cache=read(),previous=cache.forecastKick;
 if(previous&&previous.generationId===info.generationId){if(previous.status!=='failed'||previous.failures>=3||Date.now()-previous.at<120000)return;}
 const owner=identity,record={generationId:info.generationId,at:Date.now(),status:'requested',failures:previous&&previous.generationId===info.generationId?previous.failures||0:0};cache.forecastKick=record;write(cache);
 wx.cloud.callFunction({name:'rhythm-forecast',data:{}}).then(response=>{
  if(identity!==owner)return;const latest=read();if(!latest.forecastKick||latest.forecastKick.generationId!==record.generationId)return;
  const result=response.result||{};latest.forecastKick=Object.assign({},record,{status:result.status==='failed'?'failed':'accepted',error:result.status==='failed'?'GENERATION_FAILED':null,failures:record.failures+(result.status==='failed'?1:0)});write(latest);
 }).catch(()=>{if(identity!==owner)return;const latest=read();if(!latest.forecastKick||latest.forecastKick.generationId!==record.generationId)return;latest.forecastKick=Object.assign({},record,{status:'failed',error:'CALL_FAILED',failures:record.failures+1});write(latest);});
}
function watchForecast(info){clearTimeout(forecastTimer);triggerForecast(info);if(visible&&info&&['queued','running'].includes(info.status))forecastTimer=setTimeout(()=>start(),30000);}
function stop(){visible=false;clearTimeout(forecastTimer);clearTimeout(retryTimer);forecastTimer=null;retryTimer=null;}
function overlay(cache,result){const state=Object.assign(empty(),result.state||{});(cache.conflicts||[]).forEach(c=>{if(c.operation)apply(state,c.operation);});(cache.pending||[]).forEach(op=>apply(state,op));cache.state=state;cache.versions=result.versions||{};cache.revision=result.revision||0;cache.forecast=result.forecast||null;}
async function flush(allowPrompt=false){if(!sessionReady||busy)return;if(!hasConsent(identity)&&!allowPrompt)return;const cache=read();if(!cache.pending.length)return;const targetOwner=identity;busy=true;const sent=clone(cache.pending.slice(0,100));
 try{const result=await call({action:'mutate',operations:sent},allowPrompt);if(identity!==targetOwner)return;const latest=read(),applied=new Set(result.applied||[]),conflicts=result.conflicts||[];latest.conflicts=(latest.conflicts||[]).concat(conflicts.map(c=>({at:new Date().toISOString(),operation:sent.find(o=>o.id===c.id),server:c})));const rejected=new Set(conflicts.map(c=>c.id));latest.pending=latest.pending.filter(o=>!applied.has(o.id)&&!rejected.has(o.id));latest.pending.forEach(op=>{if(sent.some(old=>applied.has(old.id)&&recordKey(old)===recordKey(op)))op.baseVersion=(result.versions||{})[recordKey(op)]||0;});overlay(latest,result);write(latest);watchForecast(latest.forecast);notify();}
 catch(e){if(!/^CONSENT_/.test(e.message||''))retry();}finally{busy=false;consentOnSave=false;}if(read().pending.length&&!retryTimer&&hasConsent(identity))flush();
}
async function wallpaper(item){if(!item||!item.fileId||item.source==='v5-fallback')return;const stored=wx.getStorageSync('rhythm-wallpaper-v1');if(stored&&stored.fileId===item.fileId){notify();return;}try{const r=await wx.cloud.downloadFile({fileID:item.fileId});const saved=await new Promise((resolve,reject)=>wx.getFileSystemManager().saveFile({tempFilePath:r.tempFilePath,success:resolve,fail:reject}));wx.setStorageSync('rhythm-wallpaper-v1',{fileId:item.fileId,date:item.date,path:saved.savedFilePath});if(stored&&stored.path)wx.getFileSystemManager().removeSavedFile({filePath:stored.path,fail(){}});notify();}catch(e){} }
function wallpaperPath(){const v=wx.getStorageSync('rhythm-wallpaper-v1'),date=new Date(Date.now()+28800000).toISOString().slice(0,10);if(v&&v.date===date&&v.path){try{wx.getFileSystemManager().accessSync(v.path);return v.path;}catch(e){}}return require('./wallpaper').path(date);}
async function start(){visible=true;if(start.loading)return;if(!wx.cloud||!wx.cloud.callFunction)return;start.loading=true;try{
 const result=await call({action:'bootstrap'});if(!result.identity)throw new Error('Cloud identity unavailable');identity=result.identity;wx.setStorageSync(ACTIVE_KEY,identity);if(result.legacyOwner)wx.setStorageSync(LEGACY_OWNER_KEY,identity);sessionReady=true;
 const cache=read();cache.pending=cache.pending||[];
 const guest=wx.getStorageSync('rhythm-cloud-guest-v1');if(guest&&guest.pending&&guest.pending.length){cache.pending=cache.pending.concat(guest.pending);wx.removeStorageSync('rhythm-cloud-guest-v1');}
 overlay(cache,result);write(cache);
 if(result.legacyOwner&&!read().legacyImported&&(hasConsent(identity)||consentOnSave))await migrateLegacy(consentOnSave).catch(()=>{}).finally(()=>{consentOnSave=false;});
 watchForecast(read().forecast);notify();wallpaper(result.wallpaper);flush(consentOnSave);
 }catch(e){sessionReady=false;retry();}finally{start.loading=false;}}
module.exports={load,save,start,stop,flush,wallpaperPath};
