const {Solar}=require('../vendor/lunar');
const TYPES=['yang-wood','yin-wood','yang-fire','yin-fire','yang-earth','yin-earth','yang-metal','yin-metal','yang-water','yin-water'];
function path(date){
 try{const key=date||new Date(Date.now()+28800000).toISOString().slice(0,10),[y,m,d]=key.split('-').map(Number),stem=Solar.fromYmdHms(y,m,d,12,0,0).getLunar().getDayInGanZhi()[0],kind=TYPES['甲乙丙丁戊己庚辛壬癸'.indexOf(stem)];if(kind)return '/assets/wallpapers-v5/'+kind+'.jpg';}catch(e){}
 return '/assets/misty-sand-trial.jpg';
}
module.exports={path};
